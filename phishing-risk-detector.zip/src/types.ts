export type CategoryKey = 'structure' | 'deception' | 'trust' | 'urgency' | 'delivery';

export interface CategoryInfo {
  name: string;
  icon: string;
  color: string;
  description: string;
}

export interface SecurityCheck {
  id: string;
  cat: CategoryKey;
  pass: boolean;
  weight: number;
  label: string;
  desc: string;
  educationalInfo?: string; // Information for the class presentation
}

export interface ScanResult {
  error: boolean;
  hostname: string;
  checks: SecurityCheck[];
  score: number;
  url: string;
  timestamp: string;
}

export interface PresetLink {
  label: string;
  url: string;
  description: string;
  type: 'safe' | 'suspicious' | 'dangerous';
}

export const CATEGORIES: Record<CategoryKey, CategoryInfo> = {
  structure: {
    name: "URL Structure",
    icon: "Layers",
    color: "#a78bfa", // violet-custom
    description: "Analyzing format, length, punycode, and subdomain depth anomalies."
  },
  deception: {
    name: "Brand Deception",
    icon: "ShieldAlert",
    color: "#ff5470", // danger
    description: "Detecting typosquatting, brand mimicry, and redirection tricks."
  },
  trust: {
    name: "Trust Signals",
    icon: "Lock",
    color: "#ffb454", // warn
    description: "Evaluating encryption, TLD reputation, and use of shortening services."
  },
  urgency: {
    name: "Urgency Indicators",
    icon: "AlertTriangle",
    color: "#43e8b0", // safe (emerald)
    description: "Scanning for urgency-inducing keywords in paths and query strings."
  },
  delivery: {
    name: "Payload Delivery",
    icon: "DownloadCloud",
    color: "#ff8a3d", // orange
    description: "Checking for scripting protocols, executable attachments, and open redirects."
  }
};

export const CAT_ORDER: CategoryKey[] = ["structure", "deception", "trust", "urgency", "delivery"];

export const CAT_ANGLE_RANGE: Record<CategoryKey, [number, number]> = {
  structure: [0, 56],
  deception: [72, 128],
  trust: [144, 200],
  urgency: [216, 256],
  delivery: [272, 344]
};

export const KNOWN_BRANDS = [
  "google", "facebook", "paypal", "apple", "microsoft", "amazon", "netflix", "instagram",
  "whatsapp", "bankofamerica", "wellsfargo", "chase", "dropbox", "linkedin", "yahoo",
  "outlook", "icloud", "binance", "coinbase", "ebay", "adobe", "github", "esewa", "khalti",
  "nabilbank", "nicasiabank", "nmb", "nepalbank"
];

export const SHORTENERS = [
  "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly", "rebrand.ly",
  "cutt.ly", "shorte.st", "tiny.cc", "rb.gy", "bl.ink"
];

export const SUSPICIOUS_TLDS = [
  "zip", "mov", "xyz", "top", "click", "link", "gq", "tk", "ml", "cf", "ga", "work", "country", "kim", "review"
];

export const PRESETS: PresetLink[] = [
  {
    label: "Safe: Official Bank Portal",
    url: "https://www.nabilbank.com/personal/dashboard",
    description: "A secure banking portal using standard HTTPS with a reputable domain and no redirection tricks.",
    type: "safe"
  },
  {
    label: "Phish: Typosquat Brand Mimicry",
    url: "https://paypa1-security-verify.xyz/login?account=update",
    description: "Mimics PayPal with a look-alike character ('1' instead of 'l'), urgency keyword stacking, and a high-abuse TLD (.xyz).",
    type: "dangerous"
  },
  {
    label: "Scam: Deep Subdomains & IP Literal",
    url: "http://192.168.1.15/secure/login/chase-online/signin.html",
    description: "Uses a bare IP address to hide identity, does not use HTTPS encryption, and uses sub-paths mimicking Chase.",
    type: "dangerous"
  },
  {
    label: "Malware: Direct Executable Delivery",
    url: "https://updates-system-critical.com/assets/download/patch_installer.exe",
    description: "Points directly to an executable file (.exe), indicating direct installation payload risk.",
    type: "dangerous"
  },
  {
    label: "Suspicious: Masked Link Shortener",
    url: "https://bit.ly/claim-tax-refund-now?urgency=high",
    description: "Uses a link shortener to obfuscate the real landing URL, combined with tax refund urgency flags.",
    type: "suspicious"
  }
];
