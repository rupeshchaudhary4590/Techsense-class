/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Shield, 
  ShieldAlert, 
  Search, 
  Download, 
  Copy, 
  Check, 
  FileText, 
  BookOpen, 
  Award, 
  Terminal, 
  ArrowRight, 
  RotateCcw, 
  HelpCircle, 
  Lock, 
  Unlock, 
  Globe, 
  Sliders, 
  Eye,
  AlertTriangle,
  DownloadCloud,
  Layers,
  ChevronRight,
  Sparkles,
  ExternalLink,
  Laptop
} from 'lucide-react';
import { 
  CategoryKey, 
  SecurityCheck, 
  ScanResult, 
  CATEGORIES, 
  CAT_ORDER, 
  CAT_ANGLE_RANGE, 
  KNOWN_BRANDS, 
  SHORTENERS, 
  SUSPICIOUS_TLDS, 
  PRESETS 
} from './types';

// Levenshtein distance for typosquatting checks
function getLevenshteinDistance(a: string, b: string): number {
  const dp = Array.from({ length: a.length + 1 }, () => new Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) dp[i][0] = i;
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = a[i - 1] === b[j - 1] ? dp[i - 1][j - 1] : 1 + Math.min(dp[i - 1][j - 1], dp[i - 1][j], dp[i][j - 1]);
    }
  }
  return dp[a.length][b.length];
}

function analyzeUrl(rawUrl: string): ScanResult {
  const checks: SecurityCheck[] = [];
  let hostname = "";
  let pathname = "";
  let search = "";
  let protocol = "";
  let parsed: URL | null = null;
  let cleanUrl = rawUrl.trim();

  const timestamp = new Date().toLocaleTimeString();

  // Handle lack of protocol
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(cleanUrl)) {
    cleanUrl = "http://" + cleanUrl;
  }

  try {
    parsed = new URL(cleanUrl);
    hostname = parsed.hostname.toLowerCase();
    pathname = parsed.pathname.toLowerCase();
    search = parsed.search.toLowerCase();
    protocol = parsed.protocol.replace(":", "");
  } catch (e) {
    return {
      error: true,
      hostname: rawUrl || "invalid-input",
      checks: [{
        id: "err-parsing",
        cat: "structure",
        pass: false,
        weight: 40,
        label: "Critical: Could not parse URL structure",
        desc: "This text does not represent a valid web link format. Cyberattackers often rely on malformed formats to confuse defensive routing agents.",
        educationalInfo: "A legitimate URL must strictly adhere to RFC 3986 guidelines. If a browser or system library cannot parse it, it represents a high routing risk."
      }],
      score: 80,
      url: rawUrl,
      timestamp
    };
  }

  const hostParts = hostname.split(".");
  const registrable = hostParts.length >= 2 ? hostParts[hostParts.length - 2] : hostname;
  const tld = hostParts.length >= 1 ? hostParts[hostParts.length - 1] : "";

  // ================= CATEGORY 1: STRUCTURE =================

  // 1. Raw IP Literal
  const ipPattern = /^(\d{1,3}\.){3}\d{1,3}$/;
  const isBareIp = ipPattern.test(hostname);
  checks.push({
    id: "struct-ip",
    cat: "structure",
    pass: !isBareIp,
    weight: 25,
    label: isBareIp ? "Raw IP address host detected" : "Domain host resolution",
    desc: isBareIp 
      ? "Uses a raw IPv4 literal as the host. Legitimate organizations host public sites via registered DNS names, never raw server IPs."
      : "Resolves to a symbolic domain name rather than a naked, numerical IP address.",
    educationalInfo: "IP addresses bypass symbolic name checking and prevent normal certificate authority identity verification, signaling direct infrastructure access typical of rapid-setup scams."
  });

  // 2. Homograph / Punycode
  const isPunycode = hostname.includes("xn--");
  checks.push({
    id: "struct-puny",
    cat: "structure",
    pass: !isPunycode,
    weight: 25,
    label: isPunycode ? "Punycode (Homograph Attack) pattern" : "Standard character encoding",
    desc: isPunycode
      ? "Uses 'xn--' prefix indicating Cyrillic or other non-Latin alphabets designed to mimic Latin characters (e.g., replacing 'o' with 'о')."
      : "The domain uses standard ASCII lettering, with no homographic unicode substitutions detected.",
    educationalInfo: "Internationalized Domain Names (IDNs) let attackers register look-alike domains. For example, replacing a Latin 'a' with a Cyrillic 'а' is indistinguishable to the human eye but points to a completely separate, malicious server."
  });

  // 3. Subdomain depth
  const subCount = Math.max(0, hostParts.length - 2);
  const isDeepSubdomain = subCount >= 3;
  checks.push({
    id: "struct-sub",
    cat: "structure",
    pass: !isDeepSubdomain,
    weight: 15,
    label: isDeepSubdomain ? `Deep subdomain chain (${hostParts.length} layers)` : "Safe subdomain level",
    desc: isDeepSubdomain
      ? `Contains ${hostParts.length} dot-separated parts. Attackers use layered subdomains (like paypal.com.verify.login.etc.com) to hide the true registered domain.`
      : `Subdomain layer count (${hostParts.length}) is within acceptable operational thresholds.`,
    educationalInfo: "Mobile web browsers frequently truncate extremely long URLs. Attackers leverage this by putting trusted names in subdomains on the left side, hiding the malicious registered domain on the right."
  });

  // 4. Excessive Hyphens
  const hyphenCount = (registrable.match(/-/g) || []).length;
  const hasExcessiveHyphens = hyphenCount >= 2;
  checks.push({
    id: "struct-hyphens",
    cat: "structure",
    pass: !hasExcessiveHyphens,
    weight: 10,
    label: hasExcessiveHyphens ? "Excessive hyphens in registered host" : "Normal hyphen count",
    desc: hasExcessiveHyphens
      ? `Detected ${hyphenCount} hyphens. Attackers frequently string together hyphenated words (e.g., 'secure-payment-update-center') to appear official.`
      : "Domain has a standard structural format with limited or zero hyphen breaks.",
    educationalInfo: "Hyphen stacking is a primary indicator of fraudulent domain registration because exact corporate name domains are already registered, forcing scammers to register multi-word dashed variants."
  });

  // 5. Total Length
  const isTooLong = rawUrl.length > 85;
  checks.push({
    id: "struct-length",
    cat: "structure",
    pass: !isTooLong,
    weight: 8,
    label: isTooLong ? `Unusually long URL length (${rawUrl.length} chars)` : "Compact URL structure",
    desc: isTooLong
      ? "URL length is abnormally long, which is a common trick used to append long base64 tracking strings or obfuscate redirect links."
      : "The link maintains a concise length, reducing hidden parameter routing risks.",
    educationalInfo: "Phishing emails and SMS alerts frequently contain excessively long URLs to push the actual domain host completely off-screen on compact smartphone displays."
  });


  // ================= CATEGORY 2: DECEPTION =================

  // 6. At-symbol redirect trick
  const hasAtSymbol = rawUrl.includes("@");
  checks.push({
    id: "decep-at",
    cat: "deception",
    pass: !hasAtSymbol,
    weight: 30,
    label: hasAtSymbol ? "Critical: User-info '@' redirection hack" : "Standard URL authority formatting",
    desc: hasAtSymbol
      ? "Contains the '@' symbol. Standard browsers ignore everything prior to '@' in the authority segment, routing users to the hidden host on the right."
      : "No user-authentication credentials or authority diversion characters found.",
    educationalInfo: "In the URL scheme 'https://google.com@evil.com', a user believes they are visiting Google, but the browser interprets 'google.com' as a username credentials prefix and routes directly to 'evil.com'."
  });

  // 7. Typosquatting / Brand Mimicry
  let typosquatBrand = "";
  let typosquatDistance = 0;
  for (const brand of KNOWN_BRANDS) {
    if (registrable === brand) continue;
    const dist = getLevenshteinDistance(registrable, brand);
    if (dist > 0 && dist <= 2 && Math.abs(registrable.length - brand.length) <= 2 && brand.length >= 4) {
      typosquatBrand = brand;
      typosquatDistance = dist;
      break;
    }
  }
  const isTyposquatted = typosquatBrand !== "";
  checks.push({
    id: "decep-typo",
    cat: "deception",
    pass: !isTyposquatted,
    weight: 30,
    label: isTyposquatted ? `Typosquat mimicry of "${typosquatBrand}"` : "Distinct domain registration",
    desc: isTyposquatted
      ? `The domain "${registrable}" is highly similar to "${typosquatBrand}" (Levenshtein edit distance of ${typosquatDistance}). This is standard credential harvesting.`
      : "Registered domain name does not closely mimic any high-reputation monitored brand assets.",
    educationalInfo: "Typosquatting targets typos made by users or exploits visual similarities (like substituting '1' for 'i', or 'rn' for 'm') to fool casual readers."
  });


  // ================= CATEGORY 3: TRUST SIGNALS =================

  // 8. Protocol Encryption (HTTPS)
  const isHttps = protocol === "https";
  checks.push({
    id: "trust-https",
    cat: "trust",
    pass: isHttps,
    weight: 15,
    label: isHttps ? "HTTPS active transport encryption" : "Insecure cleartext HTTP transport",
    desc: isHttps
      ? "Uses encrypted HTTPS protocol, safeguarding data in transit (though scammers can still acquire SSL certs)."
      : "Uses obsolete HTTP. All modern legitimate authentication, identity, and financial portals strictly mandate HTTPS.",
    educationalInfo: "While over 80% of phishing sites now use HTTPS to display the pad-lock icon, any landing page asking for credentials that is served over HTTP is a critical security breach."
  });

  // 9. High-Abuse TLDs
  const isSuspiciousTld = SUSPICIOUS_TLDS.includes(tld);
  checks.push({
    id: "trust-tld",
    cat: "trust",
    pass: !isSuspiciousTld,
    weight: 15,
    label: isSuspiciousTld ? `High-abuse TLD Extension (.${tld})` : "Standard reputation TLD",
    desc: isSuspiciousTld
      ? `The top-level domain '.${tld}' is classified as high-risk, as registries offer these domains for pennies with virtually zero identity checks.`
      : `The top-level domain '.${tld}' belongs to a mainstream or strictly authenticated registry asset.`,
    educationalInfo: "TLDs like .xyz, .top, .click, or .zip are heavily favored by disposable phishing campaigns due to automated registration scripts and bulk discount pricing."
  });

  // 10. Link Shorteners
  const isLinkShortener = SHORTENERS.some(s => hostname === s || hostname.endsWith("." + s));
  checks.push({
    id: "trust-short",
    cat: "trust",
    pass: !isLinkShortener,
    weight: 15,
    label: isLinkShortener ? "URL Shortener obfuscation" : "Transparent domain host",
    desc: isLinkShortener
      ? "Uses a generic URL-shortening service. This acts as a curtain, hiding the final destination from local inspectable scanning rules."
      : "The direct, actual host domain is transparently exposed in the address string.",
    educationalInfo: "Link shorteners are extremely dangerous in messaging channels because they force users to click blindly. Legitimate services use internal, branded, short links (like amzn.to) rather than anonymous general ones."
  });


  // ================= CATEGORY 4: URGENCY =================

  // 11. Urgency Keywords
  const urgencyKeywords = ["login", "verify", "secure", "account", "update", "confirm", "signin", "password", "banking", "suspended", "unlock", "billing", "recovery"];
  const matchedKeywords = urgencyKeywords.filter(k => pathname.includes(k) || search.includes(k) || hostname.includes(k));
  const hasKeywordStacking = matchedKeywords.length >= 2;
  checks.push({
    id: "urgent-stack",
    cat: "urgency",
    pass: !hasKeywordStacking,
    weight: 15,
    label: hasKeywordStacking ? `Urgency keyword stuffing (${matchedKeywords.length} found)` : "Neutral URL semantic path",
    desc: hasKeywordStacking
      ? `Contains high-alert keywords: [${matchedKeywords.join(", ")}]. Attackers stack these words in sub-paths to panic users into clicking.`
      : "The path structure maintains functional naming, without stacking administrative panic words.",
    educationalInfo: "Phishing URLs rely on social engineering. Stacking keywords like 'account-suspended-verify-login' simulates a highly authoritative, critical notification, distracting users from analyzing the actual host."
  });


  // ================= CATEGORY 5: DELIVERY RISK =================

  // 12. Executable scheme
  const isExecScheme = ["javascript", "data", "vbscript", "file"].includes(protocol);
  checks.push({
    id: "deliv-scheme",
    cat: "delivery",
    pass: !isExecScheme,
    weight: 35,
    label: isExecScheme ? `Malicious script execution URI (${protocol}:)` : "Safe web transport scheme",
    desc: isExecScheme
      ? `Uses an active code-delivery protocol '${protocol}:'. Opening this link can immediately run arbitrary scripts or open administrative file-roots on your local operating system.`
      : "Uses standard, non-executable web protocol frameworks (HTTP/HTTPS).",
    educationalInfo: "The 'javascript:' or 'data:text/html' schemes let attackers embed entire websites or scripts directly inside a clickable hyperlink, executing code immediately inside the client browser scope."
  });

  // 13. Executable File Attachment
  const dangerousExt = /\.(exe|scr|bat|cmd|msi|apk|jar|vbs|ps1|dll|lnk|com|pif|dmg|sh)(\?|$)/i;
  const isDirectDownload = dangerousExt.test(pathname);
  checks.push({
    id: "deliv-download",
    cat: "delivery",
    pass: !isDirectDownload,
    weight: 30,
    label: isDirectDownload ? "Direct malware downloader payload" : "Standard document content route",
    desc: isDirectDownload
      ? "Links directly to an executable program or script installer. Cybercriminals use this to launch automatic, drive-by malware downloads."
      : "The destination path points to a standard hypermedia page rather than a system-executable payload.",
    educationalInfo: "A drive-by download occurs when an executive or client clicks a link that immediately triggers a browser prompt to save and run a script or installer, commonly disguised as a 'critical security update' or 'bank-patch'."
  });

  // 14. Open Redirects
  const redirectParams = ["redirect", "url", "next", "return", "dest", "destination", "continue", "rurl", "target", "out"];
  let hasOpenRedirect = false;
  try {
    for (const key of redirectParams) {
      const val = parsed?.searchParams.get(key);
      if (val && /^https?(:\/\/|%3a%2f%2f)/i.test(val)) {
        hasOpenRedirect = true;
        break;
      }
    }
  } catch (e) {}
  checks.push({
    id: "deliv-redirect",
    cat: "delivery",
    pass: !hasOpenRedirect,
    weight: 20,
    label: hasOpenRedirect ? "Open-redirect routing loop" : "Clean link routing boundary",
    desc: hasOpenRedirect
      ? "An active query parameter instructs the site to immediately forward the user to a secondary external URL. This is used to bypass secure email gateways."
      : "The URL does not contain an apparent unvalidated open redirection structure.",
    educationalInfo: "Attackers look for open redirect scripts on trusted domains. For example, a link to 'https://google.com/url?q=https://evil.com' passes security filters that only check the main host, but instantly redirects the human user to the malicious server."
  });

  // 15. Obfuscated Encoding
  const percentEncodedCount = (rawUrl.match(/%[0-9a-fA-F]{2}/g) || []).length;
  const hasHeavyEncoding = percentEncodedCount >= 6;
  checks.push({
    id: "deliv-obfus",
    cat: "delivery",
    pass: !hasHeavyEncoding,
    weight: 12,
    label: hasHeavyEncoding ? `Heavy percent-encoding (${percentEncodedCount} chars)` : "Transparent URL encoding",
    desc: hasHeavyEncoding
      ? `Contains heavy percent-encoding. This is a common defense evasion technique designed to scramble words so security scanners cannot read them.`
      : "URL characters are mostly readable with minimal hexadecimal conversion structures.",
    educationalInfo: "Percent encoding converts characters to hexadecimal ASCII values (like %2F for '/'). Heavy encoding hides brand trademarks, suspicious paths, or automated commands from simple string searches in security gateways."
  });

  // Calculate final score
  const totalRiskWeight = checks.reduce((sum, c) => sum + (c.pass ? 0 : c.weight), 0);
  const score = Math.min(100, totalRiskWeight);

  return {
    error: false,
    hostname,
    checks,
    score,
    url: rawUrl,
    timestamp
  };
}

// Generate the fully single-file HTML code for export/download
function generateHTMLCode(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LINK FORENSICS // Phishing Risk Score</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&family=Share+Tech+Mono&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #08070d;
    --panel: #0f0d19;
    --panel-2: #171325;
    --border: #2a2440;
    --border-soft: #1d1930;
    --text: #ece8f7;
    --muted: #8b84a8;
    --muted-dim: #524a72;
    --safe: #43e8b0;
    --warn: #ffb454;
    --danger: #ff5470;
    --violet: #a78bfa;
    --grid: #1a1628;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body {
    background: radial-gradient(ellipse 900px 500px at 50% -10%, #1c1530 0%, transparent 60%), var(--bg);
    color: var(--text);
    font-family: 'Inter', -apple-system, sans-serif;
    min-height: 100vh;
    overflow-x: hidden;
  }
  .mono {
    font-family: 'Share Tech Mono', monospace;
    letter-spacing: 0.3px;
  }
  .display {
    font-family: 'Orbitron', sans-serif;
    letter-spacing: 0.4px;
  }
  .wrap {
    max-width: 800px;
    margin: 0 auto;
    padding: 40px 20px 70px;
    opacity: 0;
    transform: translateY(14px);
    transition: opacity 0.6s ease, transform 0.6s ease;
  }
  .wrap.show { opacity: 1; transform: translateY(0); }

  /* ---- Landing screen ---- */
  .landing {
    position: fixed;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 50;
    background: radial-gradient(ellipse 700px 500px at 50% 40%, #221a3d 0%, transparent 65%), var(--bg);
    transition: opacity 0.55s ease, transform 0.55s ease;
  }
  .landing.hide {
    opacity: 0;
    transform: scale(1.04);
    pointer-events: none;
  }
  .landing-grid {
    position: absolute;
    inset: 0;
    background-image:
      linear-gradient(var(--grid) 1px, transparent 1px),
      linear-gradient(90deg, var(--grid) 1px, transparent 1px);
    background-size: 42px 42px;
    mask-image: radial-gradient(ellipse 600px 460px at 50% 45%, #000 20%, transparent 75%);
    -webkit-mask-image: radial-gradient(ellipse 600px 460px at 50% 45%, #000 20%, transparent 75%);
    animation: gridPan 16s linear infinite;
  }
  @keyframes gridPan {
    from { background-position: 0 0; }
    to { background-position: 42px 42px; }
  }
  .landing-inner {
    position: relative;
    z-index: 2;
    text-align: center;
    padding: 20px;
    max-width: 540px;
  }
  .landing-eyebrow {
    font-size: 11px;
    letter-spacing: 3px;
    color: var(--muted-dim);
    margin-bottom: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
  }
  .landing-eyebrow .blinker {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--safe);
    box-shadow: 0 0 8px var(--safe);
    animation: blink 1.4s ease infinite;
  }
  @keyframes blink { 0%,100% { opacity:1; } 50% { opacity:0.25; } }
  .landing-title {
    font-size: 42px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 5px;
    line-height: 1.15;
    margin-bottom: 14px;
    background: linear-gradient(180deg, #f4f1fc 0%, #b9adf0 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: 0 0 46px rgba(167,139,250,0.35);
  }
  .landing-title .dot { color: var(--violet); }
  .landing-typed {
    min-height: 20px;
    font-size: 13.5px;
    color: var(--safe);
    margin-bottom: 30px;
  }
  .landing-typed .cursor {
    display: inline-block;
    width: 7px;
    height: 14px;
    background: var(--safe);
    margin-left: 3px;
    vertical-align: -2px;
    animation: blink 0.9s steps(1) infinite;
  }
  .enter-btn {
    background: var(--violet);
    color: #150f28;
    border: none;
    font-weight: 700;
    font-size: 13.5px;
    letter-spacing: 1.2px;
    padding: 16px 32px;
    border-radius: 8px;
    cursor: pointer;
    opacity: 0;
    transform: translateY(10px) scale(0.97);
    transition: opacity 0.5s ease, transform 0.5s ease, box-shadow 0.25s ease;
  }
  .enter-btn.ready {
    opacity: 1;
    transform: translateY(0) scale(1);
    animation: btnPulse 2.4s ease infinite;
  }
  .enter-btn:hover { box-shadow: 0 0 32px 4px rgba(167,139,250,0.55); }
  .enter-btn:active { transform: scale(0.96); }
  @keyframes btnPulse {
    0%,100% { box-shadow: 0 0 0 0 rgba(167,139,250,0.35); }
    50% { box-shadow: 0 0 0 10px rgba(167,139,250,0); }
  }
  .landing-foot {
    margin-top: 25px;
    font-size: 10.5px;
    color: var(--muted-dim);
    opacity: 0;
    transition: opacity 0.6s ease 0.15s;
  }
  .landing-foot.ready { opacity: 1; }

  /* ---- Header ---- */
  .eyebrow {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 11px;
    color: var(--muted-dim);
    margin-bottom: 12px;
  }
  .eyebrow .line { flex: 1; height: 1px; background: var(--border-soft); }
  .back-btn {
    background: transparent;
    border: 1px solid var(--border-soft);
    color: var(--muted);
    font-size: 10.5px;
    padding: 6px 12px;
    border-radius: 6px;
    cursor: pointer;
    transition: border-color 0.15s ease, color 0.15s ease;
  }
  .back-btn:hover { border-color: var(--violet); color: var(--violet); }
  h1.display { font-size: 26px; text-transform: uppercase; margin-bottom: 6px; }
  h1.display .accent { color: var(--violet); }
  .subtitle { font-size: 14px; color: var(--muted); margin-bottom: 24px; line-height: 1.5; }

  /* ---- Presets ---- */
  .preset-section {
    margin-bottom: 20px;
  }
  .preset-label {
    font-size: 10px;
    color: var(--muted-dim);
    letter-spacing: 1.4px;
    margin-bottom: 8px;
    text-transform: uppercase;
  }
  .preset-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }
  .preset-btn {
    background: var(--panel-2);
    border: 1px solid var(--border-soft);
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 11.5px;
    color: var(--muted);
    cursor: pointer;
    transition: all 0.15s ease;
    text-align: left;
  }
  .preset-btn:hover {
    border-color: var(--border);
    color: var(--text);
    background: var(--border-soft);
  }
  .preset-btn.safe:hover { border-color: var(--safe); color: var(--safe); }
  .preset-btn.dangerous:hover { border-color: var(--danger); color: var(--danger); }

  /* ---- Input Dossier ---- */
  .dossier {
    border: 1px solid var(--border);
    background: var(--panel);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 24px;
  }
  .field-label { font-size: 10px; letter-spacing: 1.4px; color: var(--muted-dim); margin-bottom: 8px; }
  .input-row { display: flex; gap: 10px; }
  .input-row input {
    flex: 1;
    background: var(--bg);
    border: 1px solid var(--border-soft);
    border-radius: 8px;
    padding: 14px 16px;
    color: var(--text);
    font-size: 14px;
    outline: none;
    transition: border-color 0.15s ease;
  }
  .input-row input:focus { border-color: var(--violet); }
  .input-row input::placeholder { color: var(--muted-dim); }
  button#scanBtn {
    background: var(--violet);
    color: #150f28;
    border: none;
    font-weight: 700;
    font-size: 13.5px;
    padding: 0 24px;
    border-radius: 8px;
    cursor: pointer;
    transition: opacity 0.15s ease;
  }
  button#scanBtn:disabled { opacity: 0.35; cursor: not-allowed; }

  /* ---- Radar Section ---- */
  .radar-section { display: flex; justify-content: center; margin: 30px 0; }
  .radar-wrap { position: relative; width: 280px; height: 280px; }
  .radar-wrap svg { width: 100%; height: 100%; overflow: visible; }
  .ring { fill: none; stroke: var(--grid); stroke-width: 1; }
  .crosshair { stroke: var(--grid); stroke-width: 1; }
  .sweep {
    transform-origin: 140px 140px;
    animation: spin 3.2s linear infinite;
    opacity: 0;
    transition: opacity 0.3s ease;
  }
  .sweep.active { opacity: 1; }
  @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }

  .blip { opacity: 0; transform-origin: center; }
  .blip.show { animation: blipIn 0.4s ease forwards; }
  @keyframes blipIn {
    from { opacity: 0; transform: scale(0); }
    to { opacity: 1; transform: scale(1); }
  }
  .blip-pulse { animation: pulse 1.8s ease-in-out infinite; }
  @keyframes pulse {
    0%,100% { opacity: 0.55; r: 5; }
    50% { opacity: 0.15; r: 11; }
  }
  .radar-center {
    position: absolute; top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    text-align: center; pointer-events: none;
  }
  .radar-center .domain {
    font-size: 11px; color: var(--muted); max-width: 140px; word-break: break-all; line-height: 1.3;
  }
  .radar-center .placeholder { font-size: 11.5px; color: var(--muted-dim); }

  /* ---- Verdict Banner ---- */
  .verdict-banner {
    display: none;
    margin-top: 20px;
    border: 1px solid var(--border);
    background: var(--panel);
    border-radius: 12px;
    padding: 22px;
    align-items: center;
    gap: 24px;
    margin-bottom: 24px;
  }
  .verdict-banner.show { display: flex; animation: fadein 0.4s ease forwards; }
  @keyframes fadein { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }

  .score-block { text-align: center; flex-shrink: 0; }
  .score-num { font-size: 44px; font-weight: 700; line-height: 1; }
  .score-max { font-size: 13px; color: var(--muted-dim); }
  .verdict-copy .tag {
    display: inline-block; font-size: 10.5px; font-weight: 700; padding: 3px 9px; border-radius: 4px; margin-bottom: 8px;
  }
  .verdict-copy h2 { font-size: 16px; text-transform: uppercase; margin-bottom: 6px; }
  .verdict-copy p { font-size: 13px; color: var(--muted); line-height: 1.45; }

  /* ---- Category Cards ---- */
  .categories { display: none; flex-direction: column; gap: 14px; }
  .categories.show { display: flex; }
  .cat-card { border: 1px solid var(--border); background: var(--panel); border-radius: 12px; overflow: hidden; }
  .cat-head { display: flex; align-items: center; gap: 12px; padding: 14px 18px; background: var(--panel-2); border-bottom: 1px solid var(--border-soft); }
  .cat-icon { width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; border-radius: 6px; font-size: 11px; flex-shrink: 0; }
  .cat-name { font-size: 13px; font-weight: 700; letter-spacing: 0.4px; }
  .cat-count { margin-left: auto; font-size: 11px; color: var(--muted-dim); }
  .check-row { display: flex; gap: 14px; padding: 12px 18px; border-bottom: 1px solid var(--border-soft); }
  .check-row:last-child { border-bottom: none; }
  .check-tag { font-size: 9.5px; font-weight: 700; padding: 3px 8px; border-radius: 4px; height: fit-content; white-space: nowrap; }
  .check-tag.fail { background: rgba(255,84,112,0.12); color: var(--danger); border: 1px solid rgba(255,84,112,0.25); }
  .check-tag.pass { background: rgba(67,232,176,0.12); color: var(--safe); border: 1px solid rgba(67,232,176,0.25); }
  .check-body .label { font-size: 13px; font-weight: 600; margin-bottom: 2px; }
  .check-body .desc { font-size: 12px; color: var(--muted); line-height: 1.4; }

  .flash { position: fixed; inset: 0; background: #ece8f7; opacity: 0; z-index: 60; pointer-events: none; }
  .flash.fire { animation: flashFire 0.5s ease forwards; }
  @keyframes flashFire { 0% { opacity: 0; } 12% { opacity: 0.85; } 100% { opacity: 0; } }

  .footnote { font-size: 11.5px; color: var(--muted-dim); line-height: 1.6; padding-top: 20px; border-top: 1px solid var(--border-soft); margin-top: 30px; display: none; }
  .footnote.show { display: block; }
</style>
</head>
<body>

<div class="flash" id="flash"></div>

<div class="landing" id="landing">
  <div class="landing-grid"></div>
  <div class="landing-inner">
    <div class="landing-eyebrow mono"><span class="blinker"></span>SYSTEM ACTIVE</div>
    <h1 class="landing-title display">LINK FORENSICS<span class="dot">.</span></h1>
    <div class="landing-typed mono" id="typedLine"><span class="cursor"></span></div>
    <button id="enterBtn" class="enter-btn mono">LAUNCH LOCAL FORENSICS</button>
    <div class="landing-foot mono" id="landingFoot">15 rule-based checks · 5 threat vectors · 100% offline</div>
  </div>
</div>

<div class="wrap" id="appView">
  <div class="eyebrow mono">
    <button id="backBtn" class="back-btn mono">← MAIN MENU</button>
    <span>SECURE LINK SCREENER</span>
    <div class="line"></div>
    <span>V3.0 // TECHSENSE</span>
  </div>

  <h1 class="display">phish<span class="accent">·</span>scan</h1>
  <p class="subtitle">Enter any target web URL below. 15 custom verification checks analyze formatting, homograph structures, brand keywords, and delivery schemes directly in your browser.</p>

  <div class="preset-section">
    <div class="preset-label mono">Present Class Demos</div>
    <div class="preset-grid">
      <button class="preset-btn safe mono" onclick="loadPreset('https://www.nabilbank.com/personal/dashboard')">🟢 Official Bank Portal</button>
      <button class="preset-btn dangerous mono" onclick="loadPreset('https://paypa1-security-verify.xyz/login?account=update')">🔴 Typosquat Brand Mimic</button>
      <button class="preset-btn dangerous mono" onclick="loadPreset('http://192.168.1.15/secure/login/chase-online/signin.html')">🔴 Bare IP No-HTTPS</button>
      <button class="preset-btn dangerous mono" onclick="loadPreset('https://updates-system-critical.com/assets/download/patch_installer.exe')">🔴 Direct Exe Malware</button>
      <button class="preset-btn dangerous mono" onclick="loadPreset('https://bit.ly/claim-tax-refund-now?urgency=high')">🟡 Masked Short Link</button>
    </div>
  </div>

  <div class="dossier">
    <div class="field-label mono">SUBJECT PATH / URL</div>
    <div class="input-row">
      <input id="urlInput" class="mono" type="text" placeholder="http://paypa1-secure.verify-login.xyz" autocomplete="off">
      <button id="scanBtn" class="mono">SCAN</button>
    </div>
  </div>

  <div class="radar-section">
    <div class="radar-wrap">
      <svg viewBox="0 0 280 280">
        <circle class="ring" cx="140" cy="140" r="30"></circle>
        <circle class="ring" cx="140" cy="140" r="65"></circle>
        <circle class="ring" cx="140" cy="140" r="100"></circle>
        <circle class="ring" cx="140" cy="140" r="130"></circle>
        <line class="crosshair" x1="140" y1="10" x2="140" y2="270"></line>
        <line class="crosshair" x1="10" y1="140" x2="270" y2="140"></line>
        <g class="sweep" id="sweep">
          <defs>
            <linearGradient id="sweepGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#a78bfa" stop-opacity="0"></stop>
              <stop offset="100%" stop-color="#a78bfa" stop-opacity="0.3"></stop>
            </linearGradient>
          </defs>
          <path d="M140,140 L140,10 A130,130 0 0,1 253,90 Z" fill="url(#sweepGrad)"></path>
        </g>
        <g id="blipLayer"></g>
      </svg>
      <div class="radar-center">
        <div class="placeholder mono" id="radarPlaceholder">idle sensor</div>
        <div class="domain mono" id="radarDomain" style="display:none;"></div>
      </div>
    </div>
  </div>

  <div class="verdict-banner" id="verdictBanner">
    <div class="score-block">
      <div class="score-num mono" id="scoreNum">0</div>
      <div class="score-max mono">/100</div>
    </div>
    <div class="verdict-copy">
      <div class="tag mono" id="verdictTag">SAFE</div>
      <h2 class="display" id="verdictTitle">—</h2>
      <p id="verdictSub">—</p>
    </div>
  </div>

  <div class="categories" id="categories"></div>

  <div class="footnote mono" id="footnote">
    <strong style="color:var(--text);">Presentation Note:</strong> This URL scanner operates purely using local deterministic algorithms without relying on live reputation lookups. This allows cybersecurity students to dissect the structural layout of threats directly.
  </div>
</div>

<script>
const BRANDS = ["google","facebook","paypal","apple","microsoft","amazon","netflix","instagram","whatsapp","bankofamerica","wellsfargo","chase","dropbox","linkedin","yahoo","outlook","icloud","binance","coinbase","ebay","adobe","github","esewa","khalti","nabilbank","nicasiabank","nmb","nepalbank"];
const SHORT = ["bit.ly","tinyurl.com","t.co","goo.gl","ow.ly","is.gd","buff.ly","rebrand.ly","cutt.ly","shorte.st","tiny.cc","rb.gy","bl.ink"];
const TOXIC_TLDS = ["zip","mov","xyz","top","click","link","gq","tk","ml","cf","ga","work","country","kim","review"];

const CAT_METADATA = {
  structure: { name: "URL STRUCTURE", icon: "◧", color: "#a78bfa" },
  deception: { name: "BRAND DECEPTION", icon: "◈", color: "#ff5470" },
  trust:     { name: "TRUST SIGNALS", icon: "◇", color: "#ffb454" },
  urgency:   { name: "URGENCY LANGUAGE", icon: "◆", color: "#43e8b0" },
  delivery:  { name: "DELIVERY RISK", icon: "▲", color: "#ff8a3d" }
};
const SEQUENCE = ["structure","deception","trust","urgency","delivery"];
const ANGLES = { structure: [0, 56], deception: [72, 128], trust: [144, 200], urgency: [216, 256], delivery: [272, 344] };

function distance(a, b) {
  const m = Array.from({length: a.length+1}, () => new Array(b.length+1).fill(0));
  for(let i=0; i<=a.length; i++) m[i][0] = i;
  for(let j=0; j<=b.length; j++) m[0][j] = j;
  for(let i=1; i<=a.length; i++) {
    for(let j=1; j<=b.length; j++) {
      m[i][j] = a[i-1]===b[j-1] ? m[i-1][j-1] : 1 + Math.min(m[i-1][j-1], m[i-1][j], m[i][j-1]);
    }
  }
  return m[a.length][b.length];
}

function analyze(raw) {
  const checks = [];
  let host = "", path = "", query = "", scheme = "";
  let target = raw.trim();
  if(!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(target)) target = "http://" + target;

  try {
    const parsed = new URL(target);
    host = parsed.hostname.toLowerCase();
    path = parsed.pathname.toLowerCase();
    query = parsed.search.toLowerCase();
    scheme = parsed.protocol.replace(":","");
  } catch(e) {
    return { error: true, hostname: raw, checks: [{cat:"structure", pass:false, weight:40, label:"Could not parse URL", desc:"This doesn't match standard URL formats."}], score: 80 };
  }

  const parts = host.split(".");
  const core = parts.length >= 2 ? parts[parts.length-2] : host;
  const extension = parts[parts.length-1];

  // 1. IP
  const isIP = /^(\\d{1,3}\\.){3}\\d{1,3}$/.test(host);
  checks.push({cat:"structure", pass:!isIP, weight:25, label:isIP?"Bare IP literal":"Standard DNS Host", desc:isIP?"Uses numerical IP host instead of domain name.":"Resolves via DNS systems."});

  // 2. Puny
  const isPuny = host.includes("xn--");
  checks.push({cat:"structure", pass:!isPuny, weight:25, label:isPuny?"Punycode Homograph Detected":"ASCII Character Set", desc:isPuny?"Uses unicode substitute characters to copy real brands.":"Uses standard web lettering."});

  // 3. Subdomains
  const isDeep = parts.length - 2 >= 3;
  checks.push({cat:"structure", pass:!isDeep, weight:15, label:isDeep?"Stacked Subdomain Chains":"Normal Domain Layers", desc:isDeep?"Has deep subdomains masking true host on right.":"Maintains typical layer count."});

  // 4. Hyphens
  const badDashes = (core.match(/-/g) || []).length >= 2;
  checks.push({cat:"structure", pass:!badDashes, weight:10, label:badDashes?"Excessive Hyphen Stacking":"Standard Dash Interval", desc:badDashes?"Uses excessive dashes to simulate corporate brand strings.":"No dash abnormalities."});

  // 5. Length
  const isLong = raw.length > 85;
  checks.push({cat:"structure", pass:!isLong, weight:8, label:isLong?"Excessive URL Length":"Reasonable Length", desc:isLong?"Overlong URL size frequently wraps parameters to hide host.":"Maintains normal size constraints."});

  // 6. At symbol
  const hasAt = raw.includes("@");
  checks.push({cat:"deception", pass:!hasAt, weight:30, label:hasAt?"'@' Authority Trick":"Valid Credential Structure", desc:hasAt?"Browser discards host parts before '@', leading to route deception.":"No authority route modifiers."});

  // 7. Typosquat
  let squatted = false;
  let squattedBrand = "";
  for (const b of BRANDS) {
    if(core === b) continue;
    const d = distance(core, b);
    if(d > 0 && d <= 2 && Math.abs(core.length - b.length) <= 2 && b.length >= 4) {
      squatted = true; squattedBrand = b; break;
    }
  }
  checks.push({cat:"deception", pass:!squatted, weight:30, label:squatted ? ('Look-alike character swap of "' + squattedBrand + '"') : "Distinct Registered Mark", desc:squatted?"Character substitutions resemble major online platforms.":"No clear brand resemblance."});

  // 8. SSL
  const isHttps = scheme === "https";
  checks.push({cat:"trust", pass:isHttps, weight:15, label:isHttps?"HTTPS SSL Transport Active":"Cleartext HTTP Protocol", desc:isHttps?"Connection uses safe secure transport socket.":"Transmits in cleartext, highly unsafe for logins."});

  // 9. TLD reputation
  const badTLD = TOXIC_TLDS.includes(extension);
  checks.push({cat:"trust", pass:!badTLD, weight:15, label:badTLD ? ('High-risk TLD (.' + extension + ')') : "Standard TLD", desc:badTLD?"TLD belongs to registries known for rapid scam deployment.":"TLD is reputable."});

  // 10. Shortener
  const isShort = SHORT.some(s => host === s || host.endsWith("."+s));
  checks.push({cat:"trust", pass:!isShort, weight:15, label:isShort?"Anonymizing URL Shortener":"Direct Destination Link", desc:isShort?"Hides final target server underneath short redirect link.":"Direct target routing is exposed."});

  // 11. Urgency Stacking
  const keywords = ["login", "verify", "secure", "account", "update", "confirm", "signin", "password", "banking", "suspended", "unlock", "billing", "recovery"];
  const matched = keywords.filter(k => path.includes(k) || query.includes(k) || host.includes(k));
  const stacked = matched.length >= 2;
  checks.push({cat:"urgency", pass:!stacked, weight:15, label:stacked?"Urgent Phishing Keyword Stacking":"Standard Semantics", desc:stacked ? ('Stacks alarmist tags: [' + matched.join(", ") + '] to scare users.') : "Neutral sub-folder paths."});

  // 12. Exec scheme
  const isExec = ["javascript", "data", "vbscript", "file"].includes(scheme);
  checks.push({cat:"delivery", pass:!isExec, weight:35, label:isExec ? ('Script Execution Scheme (' + scheme + '):') : "Secure Content Scheme", desc:isExec?"Clicking launches automated browser scripts or opens local system files.":"Strict web transfer standards."});

  // 13. Downloadable binary
  const dangerousExt = /\\.(exe|scr|bat|cmd|msi|apk|jar|vbs|ps1|dll|lnk|com|pif|dmg|sh)(\\?|$)/i;
  const isDl = dangerousExt.test(path);
  checks.push({cat:"delivery", pass:!isDl, weight:30, label:isDl?"Direct Executable Download Payload":"Web Document Destination", desc:isDl?"URL routes to standard executable machine files.":"Destination leads to hypermedia files."});

  // 14. Open redirects
  const openParams = ["redirect", "url", "next", "return", "dest", "destination", "continue", "rurl", "target", "out"];
  let redirected = false;
  try {
    for (const k of openParams) {
      const v = parsed ? new URL(target).searchParams.get(k) : null;
      if (v && /^https?(:\/\/|%3a%2f%2f)/i.test(v)) { redirected = true; break; }
    }
  } catch(e){}
  checks.push({cat:"delivery", pass:!redirected, weight:20, label:redirected?"Unvalidated Open Redirect Route":"Isolated Route Path", desc:redirected?"Contains queries telling domain to hand off user to third-party host.":"Isolated routing frame."});

  // 15. Scrambled Encoding
  const encodedCount = (raw.match(/%[0-9a-fA-F]{2}/g) || []).length;
  const heavy = encodedCount >= 6;
  checks.push({cat:"delivery", pass:!heavy, weight:12, label:heavy?"Heavy Percent-Encoding Obfuscation":"Readable Query Structure", desc:heavy ? ('Found ' + encodedCount + ' encoded items. Used to bypass literal word checks.') : "No obfuscated encoding patterns."});

  const score = Math.min(100, checks.reduce((sum, c) => sum + (c.pass ? 0 : c.weight), 0));
  return { error: false, hostname: host, checks, score };
}

function polar(cx, cy, r, deg) {
  const rad = (deg - 90) * Math.PI / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

function renderRadar(res) {
  const layer = document.getElementById("blipLayer");
  layer.innerHTML = "";
  const cx = 140, cy = 140;
  const grouped = {};
  SEQUENCE.forEach(s => grouped[s] = []);
  res.checks.forEach(c => grouped[c.cat].push(c));

  let delay = 0;
  SEQUENCE.forEach(cat => {
    const items = grouped[cat];
    const [aStart, aEnd] = ANGLES[cat];
    const color = CAT_METADATA[cat].color;
    items.forEach((item, i) => {
      const angle = items.length === 1 ? (aStart+aEnd)/2 : aStart + (aEnd-aStart) * (i/(items.length-1));
      const radius = item.pass ? 118 : Math.max(28, 118 - (item.weight/30)*90);
      const {x, y} = polar(cx, cy, radius, angle);
      const blipColor = item.pass ? "#43e8b0" : color;

      const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
      g.setAttribute("class", "blip");
      g.style.animationDelay = delay + 'ms';
      delay += 50;

      if(!item.pass) {
        const pulse = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        pulse.setAttribute("cx", x); pulse.setAttribute("cy", y); pulse.setAttribute("r", 5);
        pulse.setAttribute("fill", blipColor);
        pulse.setAttribute("class", "blip-pulse");
        g.appendChild(pulse);
      }

      const dot = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      dot.setAttribute("cx", x); dot.setAttribute("cy", y); dot.setAttribute("r", item.pass ? 3.5 : 5);
      dot.setAttribute("fill", blipColor);
      dot.setAttribute("stroke", "#08070d");
      dot.setAttribute("stroke-width", "1.5");
      g.appendChild(dot);

      layer.appendChild(g);
      requestAnimationFrame(() => g.classList.add("show"));
    });
  });
}

function scoreAnim(target) {
  const el = document.getElementById("scoreNum");
  let cur = 0;
  const step = Math.max(1, Math.round(target/25));
  const iv = setInterval(() => {
    cur += step;
    if(cur >= target) { cur = target; clearInterval(iv); }
    el.textContent = cur;
  }, 20);
}

function renderResult(res) {
  document.getElementById("radarPlaceholder").style.display = "none";
  const dom = document.getElementById("radarDomain");
  dom.style.display = "block";
  dom.textContent = res.hostname;

  renderRadar(res);

  const score = res.score;
  let color, tag, title, sub;
  if(score >= 55) {
    color = "var(--danger)"; tag = "HIGH RISK";
    title = "Extreme Risk Indicators Active";
    sub = "This URL layout exhibits major indicators tied directly to credentials harvesting, malware deliveries, and social fraud attempts.";
  } else if(score >= 25) {
    color = "var(--warn)"; tag = "SUSPICIOUS";
    title = "Intermediate Red Flags Found";
    sub = "URL structure displays security gaps. Evaluate the source authority and communication context before visiting.";
  } else {
    color = "var(--safe)"; tag = "LOW RISK";
    title = "Nominal URL Metrics";
    sub = "No structural, brand impersonation, or script execution anomalies found. Remember to inspect live site content.";
  }

  const banner = document.getElementById("verdictBanner");
  const num = document.getElementById("scoreNum");
  const vTag = document.getElementById("verdictTag");
  
  num.style.color = color;
  vTag.textContent = tag;
  vTag.style.background = color === "var(--danger)" ? "#ff547022" : color === "var(--warn)" ? "#ffb45422" : "#43e8b022";
  vTag.style.color = color;
  vTag.style.border = '1px solid ' + (color === "var(--danger)" ? "#ff547055" : color === "var(--warn)" ? "#ffb45455" : "#43e8b055");
  
  document.getElementById("verdictTitle").textContent = title;
  document.getElementById("verdictSub").textContent = sub;
  banner.classList.add("show");
  scoreAnim(score);

  const list = document.getElementById("categories");
  list.innerHTML = "";
  const grouped = {};
  SEQUENCE.forEach(s => grouped[s] = []);
  res.checks.forEach(c => grouped[c.cat].push(c));

  SEQUENCE.forEach(key => {
    const meta = CAT_METADATA[key];
    const items = grouped[key];
    const flags = items.filter(i => !i.pass).length;
    const card = document.createElement("div");
    card.className = "cat-card";
    card.innerHTML = '<div class="cat-head">' +
      '<div class="cat-icon mono" style="background:' + meta.color + '22; color:' + meta.color + '; border:1px solid ' + meta.color + '44;">' + meta.icon + '</div>' +
      '<div class="cat-name mono">' + meta.name + '</div>' +
      '<div class="cat-count mono">' + flags + ' flag' + (flags === 1 ? '' : 's') + ' / ' + items.length + '</div>' +
    '</div>';

    items.forEach(i => {
      const row = document.createElement("div");
      row.className = "check-row";
      row.innerHTML = '<div class="check-tag mono ' + (i.pass ? 'pass' : 'fail') + '">' + (i.pass ? 'PASS' : 'FLAG') + '</div>' +
        '<div class="check-body">' +
          '<div class="label">' + i.label + '</div>' +
          '<div class="desc">' + i.desc + '</div>' +
        '</div>';
      card.appendChild(row);
    });
    list.appendChild(card);
  });
  list.classList.add("show");
  document.getElementById("footnote").classList.add("show");
}

const scanBtn = document.getElementById("scanBtn");
const urlInput = document.getElementById("urlInput");
const sweep = document.getElementById("sweep");

function executeScan() {
  const val = urlInput.value.trim();
  if(!val) return;
  document.getElementById("verdictBanner").classList.remove("show");
  document.getElementById("categories").classList.remove("show");
  document.getElementById("footnote").classList.remove("show");
  document.getElementById("blipLayer").innerHTML = "";
  sweep.classList.add("active");
  scanBtn.disabled = true;
  setTimeout(() => {
    const res = analyze(val);
    sweep.classList.remove("active");
    scanBtn.disabled = false;
    renderResult(res);
  }, 950);
}

function loadPreset(link) {
  urlInput.value = link;
  executeScan();
}

scanBtn.addEventListener("click", executeScan);
urlInput.addEventListener("keydown", e => { if(e.key === "Enter") executeScan(); });

/* ---- Landing sequence ---- */
(function() {
  const logs = [
    "> loading threat matrices...",
    "> parsing 15 detection rules...",
    "> loading interactive radar interface...",
    "> system live."
  ];
  const typedEl = document.getElementById("typedLine");
  const enterBtn = document.getElementById("enterBtn");
  const foot = document.getElementById("landingFoot");
  const cursor = '<span class="cursor"></span>';

  let lIdx = 0, cIdx = 0;
  function typing() {
    if(lIdx >= logs.length) {
      enterBtn.classList.add("ready");
      foot.classList.add("ready");
      return;
    }
    const txt = logs[lIdx];
    if(cIdx <= txt.length) {
      typedEl.innerHTML = txt.slice(0, cIdx) + cursor;
      cIdx++;
      setTimeout(typing, lIdx === logs.length-1 ? 25 : 15);
    } else {
      lIdx++; cIdx = 0;
      setTimeout(typing, 250);
    }
  }
  setTimeout(typing, 350);

  const landing = document.getElementById("landing");
  const appView = document.getElementById("appView");
  const flash = document.getElementById("flash");

  enterBtn.addEventListener("click", () => {
    flash.classList.add("fire");
    landing.classList.add("hide");
    setTimeout(() => {
      landing.style.display = "none";
      appView.style.display = "block";
      requestAnimationFrame(() => {
        requestAnimationFrame(() => appView.classList.add("show"));
      });
      urlInput.focus();
    }, 450);
  });

  document.getElementById("backBtn").addEventListener("click", () => {
    appView.classList.remove("show");
    setTimeout(() => {
      appView.style.display = "none";
      landing.style.display = "flex";
      requestAnimationFrame(() => {
        requestAnimationFrame(() => landing.classList.remove("hide"));
      });
    }, 450);
  });
})();
</script>
</body>
</html>`;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'scanner' | 'companion' | 'exporter'>('scanner');
  const [urlInput, setUrlInput] = useState('https://paypa1-security-verify.xyz/login?account=update');
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [copied, setCopied] = useState(false);
  
  // Presentation Companion states
  const [activeSlide, setActiveSlide] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, boolean>>({});
  const [activeExplainId, setActiveExplainId] = useState<string | null>(null);

  // Radar Ref and effect
  const sweepRef = useRef<SVGPathElement>(null);

  const slides = [
    {
      title: "The Anatomy of Link Phishing",
      subtitle: "Why URL analysis is the first line of defense",
      points: [
        { label: "DNS vs Paths", text: "Human eyes get fooled by paths (e.g. facebook.com.attacker.xyz). Attackers place famous brands in the subdomain space, leaving their true registrable domain on the far right." },
        { label: "Social Engineering Trigger", text: "Security and account updates are simulated with stacked administrative vocabulary (verify, secure, update, banking) to inject urgent panic." },
        { label: "The Mobile Screen Threat", text: "Compact displays naturally truncate addresses, hiding critical malicious indicators completely from visual lines of sight." }
      ],
      interactiveLabel: "Visualizing URL components:",
      visualizer: (
        <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-sm font-mono space-y-3">
          <div className="text-slate-500 text-xs">// URL component breakdown</div>
          <div className="flex flex-wrap gap-1 leading-relaxed text-xs">
            <span className="text-emerald-400 font-bold bg-emerald-950/40 px-1 rounded border border-emerald-900/50">https://</span>
            <span className="text-violet-400 bg-violet-950/40 px-1 rounded border border-violet-900/50">paypa1-security-update.</span>
            <span className="text-rose-400 font-bold bg-rose-950/40 px-1 rounded border border-rose-900/50">verify-account.xyz</span>
            <span className="text-amber-400 bg-amber-950/40 px-1 rounded border border-amber-900/50">/login?session=active</span>
          </div>
          <div className="grid grid-cols-2 gap-3 pt-2 text-[11px] border-t border-slate-900">
            <div><span className="text-emerald-400 font-bold">🟢 Protocol:</span> Must be HTTPS.</div>
            <div><span className="text-violet-400">🟣 Subdomains:</span> Impersonation layer.</div>
            <div><span className="text-rose-400 font-bold">🔴 Registered Domain:</span> The actual host (.xyz)!</div>
            <div><span className="text-amber-400">🟡 Path & Query:</span> Keyword stuffing field.</div>
          </div>
        </div>
      )
    },
    {
      title: "Understanding Look-Alikes",
      subtitle: "Homographs, Typosquatting, and Domain Spoofing",
      points: [
        { label: "Levenshtein Metric", text: "Measures the distance of text differences. Character swaps (e.g. paypa1 vs paypal) represent 1 edit difference. Phishing tools scan for high similarity." },
        { label: "Punycode Attacks", text: "Using IDN internationalized domains (xn--), attackers register unicode characters (like Cyrillic 'а') that look identical to regular characters." },
        { label: "Alternative TLD Abuse", text: "Cheap, bulk-registered domains (.top, .xyz, .click) allow rapid campaign testing, frequently utilizing automatic deletion bypass scripts." }
      ],
      interactiveLabel: "Homograph Interactive Test:",
      visualizer: (
        <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs font-mono space-y-3">
          <div className="text-slate-400 font-bold">Can your class spot the fake?</div>
          <div className="space-y-2">
            <div className="flex justify-between items-center p-2 bg-slate-900 rounded border border-slate-800">
              <span className="text-emerald-400">paypal.com</span>
              <span className="text-[10px] text-slate-500 bg-slate-950 px-2 py-0.5 rounded">AUTHENTIC ASCII</span>
            </div>
            <div className="flex justify-between items-center p-2 bg-slate-900 rounded border border-slate-800">
              <span className="text-rose-400">paypaⅠ.com</span>
              <span className="text-[10px] text-rose-500 bg-rose-950/20 border border-rose-900/40 px-2 py-0.5 rounded">unicode sub (Ⅰ vs l)</span>
            </div>
            <div className="flex justify-between items-center p-2 bg-slate-900 rounded border border-slate-800">
              <span className="text-rose-400">paypa1.com</span>
              <span className="text-[10px] text-rose-500 bg-rose-950/20 border border-rose-900/40 px-2 py-0.5 rounded">number substitution</span>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Delivery Mechanics & Evasion",
      subtitle: "How malicious links bypass email gateways",
      points: [
        { label: "Open Redirect Laundering", text: "Attackers route links through parameters on trusted sites (e.g., google.com/url?q=malicious.com) so local spam filters authorize the initial domain." },
        { label: "Percent-Encoding", text: "Scrambling text characters using hex codes (e.g. %20, %2F) masks trademarks and critical alarms from basic corporate regex filters." },
        { label: "Executable Payloads", text: "Disguising scripts inside installer formats (.exe, .scr, .apk) triggers client-side installs immediately upon click action." }
      ],
      interactiveLabel: "Redirection Chain Vector:",
      visualizer: (
        <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-[11px] font-mono space-y-3">
          <div className="text-slate-500">// Laundered Link Redirect Chain</div>
          <div className="space-y-1.5">
            <div className="p-1.5 bg-slate-900 rounded border border-emerald-950 text-emerald-400">
              Step 1: Trusted corporate domain: https://trusted-partner.com/out?url=...
            </div>
            <div className="text-center text-slate-600">▼ (Redirect occurs instantly)</div>
            <div className="p-1.5 bg-slate-900 rounded border border-rose-950 text-rose-400">
              Step 2: Harvesting page: http://paypa1-security-update.verify-account.xyz
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Interactive Classroom Quiz",
      subtitle: "Test your TechSense students' security awareness",
      quiz: [
        {
          question: "1. Why is HTTPS not a 100% guarantee of domain safety?",
          options: [
            "A. Modern phishing kits automate SSL registration, easily establishing encrypted tunnels on malicious host domains.",
            "B. HTTPS is obsolete and modern browsers ignore it.",
            "C. Browsers bypass HTTPS checking on mobile devices."
          ],
          correct: 0,
          explanation: "Over 80% of active phishing sites leverage HTTPS! HTTPS only guarantees that the data tunnel is encrypted, not that the recipient at the other end is safe."
        },
        {
          question: "2. How does the user-info '@' trick deceive visitors?",
          options: [
            "A. It triggers an automatic browser security check in background threads.",
            "B. Browsers completely ignore everything before the '@' sign, treating it as a login username, and routing to the right hand domain.",
            "C. It converts standard ASCII domains into secure Punycode."
          ],
          correct: 1,
          explanation: "In 'https://paypal.com@scam-server.xyz', the browser treats 'paypal.com' as a credentials string, routing the user to the real host domain: 'scam-server.xyz'!"
        }
      ]
    }
  ];

  // Trigger scanning animation
  const handleScan = (urlToScan: string) => {
    if (!urlToScan.trim()) return;
    setIsScanning(true);
    setScanResult(null);

    // Radar sweep activation
    if (sweepRef.current) {
      sweepRef.current.classList.add('active');
    }

    setTimeout(() => {
      const result = analyzeUrl(urlToScan);
      setScanResult(result);
      setIsScanning(false);
      if (sweepRef.current) {
        sweepRef.current.classList.remove('active');
      }
    }, 1100);
  };

  const loadPresetIntoScan = (url: string) => {
    setUrlInput(url);
    handleScan(url);
  };

  const handleDownload = () => {
    const code = generateHTMLCode();
    const blob = new Blob([code], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'link_forensics_scanner.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopy = () => {
    const code = generateHTMLCode();
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Run initial scan on load to populate state
  useEffect(() => {
    handleScan('https://paypa1-security-verify.xyz/login?account=update');
  }, []);

  return (
    <div className="min-h-screen bg-[#08070d] text-[#ece8f7] font-sans selection:bg-purple-900/40 relative">
      
      {/* Absolute Background Accent Radiance */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[450px] bg-gradient-to-b from-purple-950/15 via-transparent to-transparent blur-3xl pointer-events-none -z-10" />

      {/* Main Structural Nav Header */}
      <nav className="border-b border-[#1d1930] bg-[#0f0d19]/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-[0_0_15px_rgba(167,139,250,0.3)]">
                <Shield className="w-5 h-5 text-slate-950 stroke-[2.5]" />
              </div>
              <div>
                <span className="font-display font-bold text-sm tracking-widest text-[#ece8f7] block leading-none">LINK FORENSICS</span>
                <span className="text-[9.5px] font-mono tracking-wider text-purple-400 uppercase">TechSense Presentation Suite</span>
              </div>
            </div>

            <div className="flex bg-[#171325] p-1 rounded-lg border border-[#2a2440] gap-1">
              <button 
                onClick={() => setActiveTab('scanner')}
                className={`px-3 py-1.5 text-xs font-mono font-bold rounded transition-all duration-150 flex items-center gap-1.5 ${activeTab === 'scanner' ? 'bg-[#a78bfa] text-slate-950' : 'text-[#8b84a8] hover:text-[#ece8f7]'}`}
              >
                <Terminal className="w-3.5 h-3.5" />
                Live Scan
              </button>
              <button 
                onClick={() => setActiveTab('companion')}
                className={`px-3 py-1.5 text-xs font-mono font-bold rounded transition-all duration-150 flex items-center gap-1.5 ${activeTab === 'companion' ? 'bg-[#a78bfa] text-slate-950' : 'text-[#8b84a8] hover:text-[#ece8f7]'}`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                Lesson Deck
              </button>
              <button 
                onClick={() => setActiveTab('exporter')}
                className={`px-3 py-1.5 text-xs font-mono font-bold rounded transition-all duration-150 flex items-center gap-1.5 ${activeTab === 'exporter' ? 'bg-[#a78bfa] text-slate-950' : 'text-[#8b84a8] hover:text-[#ece8f7]'}`}
              >
                <DownloadCloud className="w-3.5 h-3.5" />
                Export Code
              </button>
            </div>

            <div className="hidden md:flex items-center gap-3">
              <button 
                onClick={handleDownload}
                className="bg-gradient-to-r from-violet-500 to-purple-500 hover:from-violet-600 hover:to-purple-600 text-slate-950 font-mono font-bold text-[11px] px-3.5 py-1.5 rounded-lg flex items-center gap-2 shadow-[0_0_15px_rgba(167,139,250,0.25)] hover:shadow-[0_0_20px_rgba(167,139,250,0.4)] active:scale-95 transition-all"
              >
                <Download className="w-3.5 h-3.5" />
                DOWNLOAD FILE
              </button>
            </div>

          </div>
        </div>
      </nav>

      {/* Main Container Scope */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        {/* TOP INTERACTIVE EXPLAINER FOR CLASSROOM */}
        <div className="mb-8 p-4 rounded-xl bg-gradient-to-r from-purple-950/20 to-indigo-950/20 border border-[#2a2440] flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span className="font-mono text-xs text-purple-400 uppercase tracking-widest font-bold">TechSense Class Assistant</span>
            </div>
            <p className="text-xs text-[#8b84a8] max-w-2xl">
              This environment allows you to run deterministic rule checks on phishing URLs. Under the <strong className="text-slate-200">Export Code</strong> tab, you can copy or download this exact operational system compiled into a <strong className="text-slate-200">single HTML file</strong> with zero dependencies—perfect for client presentation or offline sandbox analysis.
            </p>
          </div>
          <div className="flex flex-wrap gap-2 w-full md:w-auto">
            <button 
              onClick={handleDownload}
              className="bg-[#171325] hover:bg-[#1d1930] border border-[#2a2440] hover:border-purple-400/50 text-[#ece8f7] font-mono text-[11px] px-3.5 py-2 rounded-lg flex items-center justify-center gap-1.5 w-full md:w-auto transition-all"
            >
              <Download className="w-3.5 h-3.5 text-purple-400" />
              Get Single HTML
            </button>
          </div>
        </div>

        {/* SCANNER VIEW TAB */}
        {activeTab === 'scanner' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* LEFT INPUT & PRESETS PANEL (5 cols) */}
            <div className="lg:col-span-5 space-y-6">
              
              <div className="border border-[#2a2440] bg-[#0f0d19] rounded-xl p-5 space-y-5">
                <div className="flex justify-between items-center pb-2 border-b border-[#1d1930]">
                  <h2 className="font-display text-sm tracking-wider font-bold">RADAR INTERACTION</h2>
                  <span className="text-[10px] font-mono text-purple-400 px-2 py-0.5 bg-purple-950/40 border border-purple-900/50 rounded-full uppercase">RULE ANALYZER</span>
                </div>

                {/* Subject Link Input bar */}
                <div className="space-y-2">
                  <label htmlFor="url-input" className="text-[10px] font-mono uppercase tracking-widest text-slate-500 block">Subject Link String</label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <input 
                        id="url-input"
                        type="text" 
                        value={urlInput}
                        onChange={(e) => setUrlInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleScan(urlInput)}
                        placeholder="http://verification-service.xyz/check"
                        className="w-full bg-[#08070d] border border-[#1d1930] focus:border-[#a78bfa] rounded-lg py-3 px-4 text-sm font-mono text-[#ece8f7] placeholder-slate-600 outline-none transition-all"
                      />
                    </div>
                    <button 
                      onClick={() => handleScan(urlInput)}
                      disabled={isScanning}
                      className="bg-[#a78bfa] disabled:bg-purple-900/30 text-slate-950 disabled:text-purple-300 font-mono font-bold text-sm px-5 rounded-lg hover:opacity-90 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {isScanning ? (
                        <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Search className="w-4 h-4" />
                      )}
                      SCAN
                    </button>
                  </div>
                </div>

                {/* Interactive Preset Launchers */}
                <div className="space-y-3">
                  <div className="text-[10px] font-mono uppercase tracking-widest text-slate-500 block">Classroom Demos (Click to load)</div>
                  <div className="grid grid-cols-1 gap-2">
                    {PRESETS.map((preset, index) => (
                      <button 
                        key={index}
                        onClick={() => loadPresetIntoScan(preset.url)}
                        className="group flex flex-col items-start p-3 bg-[#171325]/50 hover:bg-[#171325] border border-[#1d1930] hover:border-[#2a2440] rounded-lg text-left transition-all relative overflow-hidden"
                      >
                        <div className="flex justify-between w-full items-center mb-1">
                          <span className="font-mono text-xs font-bold text-slate-300 group-hover:text-purple-300 flex items-center gap-1.5 transition-all">
                            <span className={`w-1.5 h-1.5 rounded-full ${
                              preset.type === 'safe' ? 'bg-[#43e8b0]' : preset.type === 'suspicious' ? 'bg-[#ffb454]' : 'bg-[#ff5470]'
                            }`} />
                            {preset.label}
                          </span>
                          <span className="text-[9px] font-mono bg-slate-950/60 px-1.5 rounded text-slate-500 uppercase">DEMO {index+1}</span>
                        </div>
                        <p className="text-[11px] text-[#8b84a8] line-clamp-1 group-hover:text-slate-300 transition-all font-mono break-all">{preset.url}</p>
                        <p className="text-[10px] text-slate-500 mt-1">{preset.description}</p>
                      </button>
                    ))}
                  </div>
                </div>

              </div>

              {/* RADAR VISUALIZATION (Plotting checks dynamically) */}
              <div className="border border-[#2a2440] bg-[#0f0d19] rounded-xl p-5 flex flex-col items-center">
                <div className="w-full flex justify-between items-center pb-2 border-b border-[#1d1930] mb-5">
                  <h2 className="font-display text-sm tracking-wider font-bold">DYNAMIC RADAR</h2>
                  <span className="text-[10px] font-mono text-purple-400">PLOT RESOLUTION</span>
                </div>

                <div className="relative w-[280px] h-[280px]">
                  <svg viewBox="0 0 280 280" className="w-full h-full overflow-visible">
                    <circle className="fill-none stroke-[#1a1628] stroke-[1]" cx="140" cy="140" r="30" />
                    <circle className="fill-none stroke-[#1a1628] stroke-[1]" cx="140" cy="140" r="65" />
                    <circle className="fill-none stroke-[#1a1628] stroke-[1]" cx="140" cy="140" r="100" />
                    <circle className="fill-none stroke-[#1a1628] stroke-[1]" cx="140" cy="140" r="130" />
                    <line className="stroke-[#1a1628] stroke-[1]" x1="140" y1="10" x2="140" y2="270" />
                    <line className="stroke-[#1a1628] stroke-[1]" x1="10" y1="140" x2="270" y2="140" />

                    {/* Sweeper Arc */}
                    <g className={`origin-[140px_140px] ${isScanning ? 'animate-spin' : 'hidden'}`} style={{ animationDuration: '3.2s', animationTimingFunction: 'linear' }}>
                      <defs>
                        <linearGradient id="sweepGradReact" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#a78bfa" stopOpacity="0" />
                          <stop offset="100%" stopColor="#a78bfa" stopOpacity="0.35" />
                        </linearGradient>
                      </defs>
                      <path d="M140,140 L140,10 A130,130 0 0,1 253,90 Z" fill="url(#sweepGradReact)" />
                    </g>

                    {/* Radar plotted Blips */}
                    {scanResult && !isScanning && (
                      <g>
                        {scanResult.checks.map((check, i) => {
                          const [aStart, aEnd] = CAT_ANGLE_RANGE[check.cat];
                          const angle = scanResult.checks.filter(c => c.cat === check.cat).length === 1 
                            ? (aStart + aEnd) / 2 
                            : aStart + (aEnd - aStart) * (scanResult.checks.filter(c => c.cat === check.cat).indexOf(check) / (scanResult.checks.filter(c => c.cat === check.cat).length - 1 || 1));
                          
                          // Risk triggers tighter radius
                          const radius = check.pass ? 118 : Math.max(28, 118 - (check.weight / 30) * 90);
                          const rad = (angle - 90) * Math.PI / 180;
                          const x = 140 + radius * Math.cos(rad);
                          const y = 140 + radius * Math.sin(rad);
                          
                          const color = check.pass ? '#43e8b0' : CATEGORIES[check.cat].color;

                          return (
                            <g key={check.id} className="animate-[scaleIn_0.3s_ease_forwards]" style={{ animationDelay: `${i * 45}ms`, transformOrigin: 'center' }}>
                              {!check.pass && (
                                <circle 
                                  cx={x} 
                                  cy={y} 
                                  r={5} 
                                  fill={color} 
                                  className="animate-ping opacity-60"
                                />
                              )}
                              <circle 
                                cx={x} 
                                cy={y} 
                                r={check.pass ? 3.5 : 5} 
                                fill={color} 
                                stroke="#08070d" 
                                strokeWidth={1.5}
                                className="cursor-pointer hover:scale-150 transition-all"
                                onClick={() => setActiveExplainId(check.id)}
                              />
                            </g>
                          );
                        })}
                      </g>
                    )}
                  </svg>

                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none w-[130px]">
                    {isScanning ? (
                      <div className="font-mono text-[10px] text-purple-400 animate-pulse tracking-widest uppercase">SCANNING...</div>
                    ) : scanResult ? (
                      <div>
                        <div className="font-mono text-[10px] text-slate-400 font-bold truncate leading-none">{scanResult.hostname}</div>
                        <div className="font-display font-black text-xs text-purple-400 mt-1">SECURE</div>
                      </div>
                    ) : (
                      <div className="font-mono text-[11px] text-slate-600">Idle Sensor</div>
                    )}
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 justify-center text-[10px] font-mono text-slate-400 border-t border-[#1d1930] pt-4 w-full">
                  <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#a78bfa]" /> Structure</div>
                  <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#ff5470]" /> Deception</div>
                  <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#ffb454]" /> Trust</div>
                  <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#43e8b0]" /> Urgency</div>
                  <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#ff8a3d]" /> Delivery</div>
                </div>
              </div>

            </div>

            {/* RIGHT SCAN DETAILED ANALYSIS PANEL (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Verdict Indicator */}
              {scanResult && !isScanning && (
                <div className="border border-[#2a2440] bg-[#0f0d19] rounded-xl p-5 flex flex-col md:flex-row items-center gap-6 animate-fade-in">
                  <div className="text-center md:border-r border-[#1d1930] pr-0 md:pr-8 flex-shrink-0">
                    <div className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">RISK SCORE</div>
                    <div className="text-5xl font-mono font-black mt-1" style={{
                      color: scanResult.score >= 55 ? '#ff5470' : scanResult.score >= 25 ? '#ffb454' : '#43e8b0'
                    }}>
                      {scanResult.score}
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 mt-1">/ 100 MAXIMUM</div>
                  </div>

                  <div className="flex-1 space-y-2 text-center md:text-left">
                    <div className="inline-block px-2.5 py-0.5 rounded text-[10px] font-mono font-black" style={{
                      backgroundColor: scanResult.score >= 55 ? 'rgba(255,84,112,0.12)' : scanResult.score >= 25 ? 'rgba(255,180,84,0.12)' : 'rgba(67,232,176,0.12)',
                      color: scanResult.score >= 55 ? '#ff5470' : scanResult.score >= 25 ? '#ffb454' : '#43e8b0',
                      border: `1px solid ${scanResult.score >= 55 ? '#ff547040' : scanResult.score >= 25 ? '#ffb45440' : '#43e8b040'}`
                    }}>
                      {scanResult.score >= 55 ? '🔴 HIGH RISK PHISHING INDICATORS' : scanResult.score >= 25 ? '🟡 SUSPICIOUS THREAT ALIGNMENT' : '🟢 LOW RISK PROFILE'}
                    </div>
                    <h3 className="font-display text-sm font-bold uppercase tracking-wider text-slate-200">
                      {scanResult.score >= 55 ? 'CRITICAL STRUCTURAL RED FLAGS' : scanResult.score >= 25 ? 'MODERATE ANOMALIES DETECTED' : 'CLEAN NOMINAL STRUCTURAL SIGNATURE'}
                    </h3>
                    <p className="text-xs text-[#8b84a8] leading-relaxed">
                      {scanResult.score >= 55 
                        ? 'This URL shows structural and semantic traits commonly leveraged in credential harvesting, brand impersonation, and drive-by scripts.'
                        : scanResult.score >= 25 
                          ? 'Minor anomalies identified. This domain exhibits traits worth verifying through standard sender identity confirmation workflows.'
                          : 'No critical anomalies identified in the URL syntax. However, remember to examine actual host identities before inputting logins.'}
                    </p>
                  </div>
                </div>
              )}

              {/* Categorized Checks Breakdown */}
              {scanResult && !isScanning && (
                <div className="space-y-4">
                  <h3 className="font-mono text-xs uppercase tracking-widest text-[#8b84a8]">Detailed Diagnostic Checklist</h3>
                  
                  {CAT_ORDER.map((catKey) => {
                    const catMeta = CATEGORIES[catKey];
                    const catChecks = scanResult.checks.filter(c => c.cat === catKey);
                    const failedCount = catChecks.filter(c => !c.pass).length;

                    return (
                      <div key={catKey} className="border border-[#1d1930] bg-[#0f0d19] rounded-xl overflow-hidden">
                        <div className="bg-[#171325] px-4 py-3 border-b border-[#1d1930] flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold font-mono" style={{ color: catMeta.color }}>
                              {catMeta.name}
                            </span>
                          </div>
                          <span className="font-mono text-[10px] text-slate-500 bg-slate-950 px-2 py-0.5 rounded-full">
                            {failedCount} flag{failedCount === 1 ? '' : 's'} / {catChecks.length} checks
                          </span>
                        </div>

                        <div className="divide-y divide-[#1d1930]">
                          {catChecks.map((check) => (
                            <div 
                              key={check.id} 
                              className={`p-4 transition-all hover:bg-slate-950/20 cursor-pointer ${activeExplainId === check.id ? 'bg-[#171325]/40' : ''}`}
                              onClick={() => setActiveExplainId(activeExplainId === check.id ? null : check.id)}
                            >
                              <div className="flex items-start gap-3">
                                <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold shrink-0 mt-0.5 ${
                                  check.pass 
                                    ? 'bg-[#43e8b0]/10 text-[#43e8b0] border border-[#43e8b0]/20' 
                                    : 'bg-[#ff5470]/10 text-[#ff5470] border border-[#ff5470]/20'
                                }`}>
                                  {check.pass ? 'PASS' : `FLAG (+${check.weight})`}
                                </span>
                                
                                <div className="flex-1 min-w-0">
                                  <div className="text-xs font-semibold text-slate-200 flex items-center justify-between">
                                    <span>{check.label}</span>
                                    <ChevronRight className={`w-3.5 h-3.5 text-slate-500 transition-transform ${activeExplainId === check.id ? 'rotate-90' : ''}`} />
                                  </div>
                                  <p className="text-[11px] text-[#8b84a8] mt-1 leading-relaxed">
                                    {check.desc}
                                  </p>

                                  {activeExplainId === check.id && check.educationalInfo && (
                                    <div className="mt-3 p-3 rounded-lg bg-slate-950/80 border border-slate-900 text-[10.5px] leading-relaxed text-purple-300">
                                      <strong className="text-slate-200 font-mono text-[9px] block uppercase tracking-wider mb-1">Cybersecurity Curriculum Note:</strong>
                                      {check.educationalInfo}
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Static Warning Banner */}
              <div className="p-4 bg-slate-950/40 border border-[#1d1930] rounded-xl text-[10.5px] font-mono text-slate-500 leading-relaxed">
                <span className="text-slate-300 font-bold block mb-1">🛡️ Preserving Presentation Context:</span>
                This system runs standard local heuristics to dissect structural traps. It does not perform live network HTTP lookups or download any content, meaning it is 100% safe to utilize with live malicious URLs for classroom demonstration without trigger logs.
              </div>

            </div>

          </div>
        )}

        {/* TEACHER PRESENTATION SUITE TAB */}
        {activeTab === 'companion' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fade-in">
            
            {/* Slide Index Rail (3 cols) */}
            <div className="lg:col-span-3 space-y-2">
              <span className="text-[10px] font-mono uppercase tracking-widest text-slate-500 block mb-3">Slide Index</span>
              {slides.map((slide, index) => (
                <button 
                  key={index}
                  onClick={() => setActiveSlide(index)}
                  className={`w-full p-3 rounded-lg border text-left flex items-start gap-3 transition-all ${
                    activeSlide === index 
                      ? 'bg-gradient-to-r from-purple-950/30 to-slate-900 border-[#a78bfa] text-[#ece8f7]' 
                      : 'bg-[#0f0d19] border-[#1d1930] hover:border-[#2a2440] text-[#8b84a8]'
                  }`}
                >
                  <span className="font-mono text-xs text-purple-400 font-bold mt-0.5">0{index + 1}</span>
                  <div>
                    <div className="text-xs font-semibold leading-tight">{slide.title}</div>
                    <div className="text-[10px] opacity-60 truncate mt-1">{slide.subtitle}</div>
                  </div>
                </button>
              ))}
            </div>

            {/* Slide Showcase Screen (9 cols) */}
            <div className="lg:col-span-9 border border-[#2a2440] bg-[#0f0d19] rounded-xl p-6 space-y-6">
              
              <div className="flex justify-between items-center border-b border-[#1d1930] pb-4">
                <span className="text-xs font-mono text-purple-400 uppercase tracking-wider font-bold">TechSense Curriculum Slides</span>
                <span className="text-xs font-mono text-slate-500">SLIDE {activeSlide + 1} OF {slides.length}</span>
              </div>

              <div className="space-y-1">
                <h2 className="font-display text-2xl font-black uppercase text-[#ece8f7] tracking-wide">
                  {slides[activeSlide].title}
                </h2>
                <p className="text-xs text-purple-300 font-mono italic">
                  {slides[activeSlide].subtitle}
                </p>
              </div>

              {/* Interactive Quiz or Core Points */}
              {slides[activeSlide].quiz ? (
                <div className="space-y-6 pt-2">
                  <div className="text-xs font-mono uppercase text-slate-400 tracking-wider">Class Assessment Mode:</div>
                  
                  {slides[activeSlide].quiz.map((q, qIndex) => (
                    <div key={qIndex} className="bg-slate-950/40 p-5 rounded-lg border border-[#1d1930] space-y-4">
                      <h4 className="text-xs font-semibold text-slate-200 font-mono leading-relaxed">{q.question}</h4>
                      
                      <div className="space-y-2">
                        {q.options.map((option, oIndex) => {
                          const isSelected = quizAnswers[qIndex] !== undefined;
                          const isCurrent = quizAnswers[qIndex] === (oIndex === q.correct);
                          
                          return (
                            <button 
                              key={oIndex}
                              onClick={() => setQuizAnswers({ ...quizAnswers, [qIndex]: oIndex === q.correct })}
                              className={`w-full p-3 rounded-lg text-left text-xs transition-all border font-mono ${
                                isSelected 
                                  ? oIndex === q.correct 
                                    ? 'bg-emerald-950/30 border-[#43e8b0] text-[#43e8b0]' 
                                    : 'bg-rose-950/15 border-rose-950 text-rose-300'
                                  : 'bg-[#171325]/40 border-[#1d1930] hover:border-[#2a2440] text-slate-300'
                              }`}
                            >
                              {option}
                            </button>
                          );
                        })}
                      </div>

                      {quizAnswers[qIndex] !== undefined && (
                        <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-[10.5px] leading-relaxed text-[#8b84a8]">
                          <strong className="text-slate-300 block mb-1">
                            {quizAnswers[qIndex] ? '✅ CORRECT ANSWER:' : '❌ REVEAL INFORMATION:'}
                          </strong>
                          {q.explanation}
                        </div>
                      )}
                    </div>
                  ))}
                  
                  <div className="text-center pt-2">
                    <button 
                      onClick={() => setQuizAnswers({})}
                      className="text-xs font-mono text-purple-400 hover:text-purple-300 underline"
                    >
                      Reset Quiz Answers
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch pt-2">
                  <div className="space-y-5">
                    <span className="text-xs font-mono uppercase text-slate-400 tracking-wider block">Core Teaching Notes:</span>
                    {slides[activeSlide].points?.map((pt, index) => (
                      <div key={index} className="space-y-1">
                        <h4 className="text-xs font-bold text-slate-200 flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#a78bfa]" />
                          {pt.label}
                        </h4>
                        <p className="text-[11.5px] text-[#8b84a8] leading-relaxed pl-3.5">
                          {pt.text}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-3 flex flex-col justify-between">
                    <span className="text-xs font-mono uppercase text-slate-400 tracking-wider block">
                      {slides[activeSlide].interactiveLabel}
                    </span>
                    <div className="flex-1 flex flex-col justify-center">
                      {slides[activeSlide].visualizer}
                    </div>
                  </div>
                </div>
              )}

              {/* Navigation buttons */}
              <div className="flex justify-between border-t border-[#1d1930] pt-4">
                <button 
                  disabled={activeSlide === 0}
                  onClick={() => setActiveSlide(activeSlide - 1)}
                  className="bg-[#171325] hover:bg-[#1d1930] border border-[#1d1930] disabled:opacity-30 text-xs font-mono text-[#ece8f7] px-4 py-2 rounded-lg transition-all"
                >
                  ◀ PREVIOUS SLIDE
                </button>
                <button 
                  disabled={activeSlide === slides.length - 1}
                  onClick={() => setActiveSlide(activeSlide + 1)}
                  className="bg-[#171325] hover:bg-[#1d1930] border border-[#1d1930] disabled:opacity-30 text-xs font-mono text-[#ece8f7] px-4 py-2 rounded-lg transition-all"
                >
                  NEXT SLIDE ▶
                </button>
              </div>

            </div>

          </div>
        )}

        {/* CODE EXPORTER AND DOWNLOAD CENTER TAB */}
        {activeTab === 'exporter' && (
          <div className="border border-[#2a2440] bg-[#0f0d19] rounded-xl p-6 space-y-6 animate-fade-in">
            
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-[#1d1930] pb-5">
              <div className="space-y-1">
                <span className="text-xs font-mono text-purple-400 uppercase tracking-widest font-bold block">Source Code Repository</span>
                <h2 className="font-display text-lg font-bold">SINGLE-FILE HTML COUPLING</h2>
                <p className="text-xs text-[#8b84a8]">
                  This compiles all the design stylesheets, modern radial sweeps, 15 forensic rule calculations, and interactive scripts into a single standalone HTML document.
                </p>
              </div>

              <div className="flex gap-2 w-full md:w-auto">
                <button 
                  onClick={handleCopy}
                  className="bg-[#171325] hover:bg-[#1d1930] border border-[#2a2440] text-[#ece8f7] font-mono text-xs px-4 py-2.5 rounded-lg flex items-center justify-center gap-2 flex-1 md:flex-none transition-all cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      COPIED!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      COPY CODE
                    </>
                  )}
                </button>
                <button 
                  onClick={handleDownload}
                  className="bg-[#a78bfa] hover:opacity-95 text-slate-950 font-mono text-xs font-bold px-4 py-2.5 rounded-lg flex items-center justify-center gap-2 flex-1 md:flex-none transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  DOWNLOAD HTML
                </button>
              </div>
            </div>

            {/* Structured code preview */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-[10px] font-mono text-slate-500">
                <span>FILE PATH: /link_forensics_scanner.html (Ready for Offline)</span>
                <span>SIZE: ~28KB · 100% SELF-CONTAINED</span>
              </div>
              <div className="bg-[#08070d] rounded-lg border border-[#1d1930] p-4 font-mono text-[11px] h-[350px] overflow-y-scroll text-slate-400 space-y-1">
                <div className="text-emerald-500">&lt;!DOCTYPE html&gt;</div>
                <div className="text-purple-400">&lt;html lang="en"&gt;</div>
                <div className="text-purple-400">&lt;head&gt;</div>
                <div className="text-slate-600 pl-4">&lt;meta charset="UTF-8"&gt;</div>
                <div className="text-slate-600 pl-4">&lt;title&gt;LINK FORENSICS // Phishing Risk Score&lt;/title&gt;</div>
                <div className="text-[#a78bfa] pl-4">&lt;style&gt;</div>
                <div className="text-slate-500 pl-8">// Custom glowing colors matching TechSense specifications</div>
                <div className="text-slate-500 pl-8">:root &#123;</div>
                <div className="text-slate-500 pl-12">--bg: #08070d;</div>
                <div className="text-slate-500 pl-12">--panel: #0f0d19;</div>
                <div className="text-slate-500 pl-12">--safe: #43e8b0;</div>
                <div className="text-slate-500 pl-12">--danger: #ff5470;</div>
                <div className="text-slate-500 pl-8">&#125;</div>
                <div className="text-slate-600 pl-8">...</div>
                <div className="text-[#a78bfa] pl-4">&lt;/style&gt;</div>
                <div className="text-purple-400">&lt;/head&gt;</div>
                <div className="text-purple-400">&lt;body&gt;</div>
                <div className="text-slate-600 pl-4">&lt;div class="landing" id="landing"&gt;</div>
                <div className="text-slate-500 pl-8">// Interactive boot sequence & title screen</div>
                <div className="text-slate-600 pl-4">&lt;/div&gt;</div>
                <div className="text-slate-600 pl-4">&lt;div class="wrap" id="appView"&gt;</div>
                <div className="text-slate-500 pl-8">// Main dashboard with interactive SVG scanning Radar</div>
                <div className="text-slate-600 pl-4">&lt;/div&gt;</div>
                <div className="text-amber-500 pl-4">&lt;script&gt;</div>
                <div className="text-slate-500 pl-8">// Full Levenshtein Distance & 15 detailed diagnostic check rules</div>
                <div className="text-slate-500 pl-8">function analyze(raw) &#123;</div>
                <div className="text-slate-500 pl-12">const checks = [];</div>
                <div className="text-slate-500 pl-12">// 15 comprehensive algorithms matching visual radar blips...</div>
                <div className="text-slate-500 pl-8">&#125;</div>
                <div className="text-slate-600 pl-8">...</div>
                <div className="text-amber-500 pl-4">&lt;/script&gt;</div>
                <div className="text-purple-400">&lt;/body&gt;</div>
                <div className="text-purple-400">&lt;/html&gt;</div>
              </div>
            </div>

            {/* Quick manual guide */}
            <div className="bg-[#171325]/40 border border-[#1d1930] p-4 rounded-lg space-y-2">
              <span className="font-mono text-xs font-bold text-slate-200 block uppercase">Class Presentation Instructions:</span>
              <ul className="text-xs text-[#8b84a8] list-decimal pl-5 space-y-1">
                <li>Click the <strong className="text-[#ece8f7]">Download HTML</strong> button above to save the <code className="bg-slate-950 px-1 rounded text-purple-300">link_forensics_scanner.html</code> file on your computer.</li>
                <li>Simply double-click the downloaded file—it opens directly in any standard browser (Chrome, Edge, Safari, Firefox).</li>
                <li>No internet connection, local Node.js servers, or specialized libraries are required to run it, guaranteeing complete sandbox safety.</li>
              </ul>
            </div>

          </div>
        )}

      </main>

      {/* FOOTER */}
      <footer className="border-t border-[#1d1930] bg-[#0f0d19]/60 py-6 mt-12 text-center text-xs font-mono text-[#524a72]">
        <div className="max-w-7xl mx-auto px-4">
          <p>Link Forensics &copy; {new Date().getFullYear()} · Created for cybersecurity presentation classes</p>
          <p className="mt-1 text-[10px] opacity-70">Client-Side Diagnostic Engine · Zero telemetry or outbound connections</p>
        </div>
      </footer>

    </div>
  );
}
