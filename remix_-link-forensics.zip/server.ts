import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

let aiInstance: GoogleGenAI | null = null;

function getGemini(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined in environment variables.");
    }
    aiInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API endpoint for AI Deep Forensic Heuristic Explanation
  app.post("/api/analyze-link", async (req, res) => {
    try {
      const { url } = req.body;
      if (!url || typeof url !== "string") {
        return res.status(400).json({ error: "A valid 'url' string is required." });
      }

      // Check for Gemini API key
      if (!process.env.GEMINI_API_KEY) {
        return res.json({
          analysis: "### ⚠️ AI Deep-Dive Unavailable\n\nTo enable AI-powered deep analysis of domain techniques, please add your `GEMINI_API_KEY` in the **Settings > Secrets** panel of AI Studio. Once added, the AI engine will provide a breakdown of homoglyph tricks, registrar risks, and phishing heuristics.",
          warning: true
        });
      }

      const ai = getGemini();
      const prompt = `You are a cybersecurity expert and link forensics specialist presenting to a "TechSense" computer science class.
Analyze this URL for phishing and deception techniques: "${url}"

Provide a scannable, educational forensic breakdown of this URL in clean Markdown.
Structure your response as follows:
- **Technique Detection**: Identify what trick (if any) this URL employs (e.g., look-alike/homoglyph characters, typosquatting, sub-domain stacking, raw IP hosting, urgency keywords, bad TLD, open redirects, etc.). If none, explain why it appears structurally standard.
- **How Attackers Use This**: Explain the exact psychology and technical trick used by malicious campaigns.
- **Defense Action**: Provide 1 clear, concrete instruction on how users can spot or avoid this.

Be highly scannable, professional, and educational. Keep the total word count under 220 words. No intro/outro conversational fluff.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
      });

      res.json({ analysis: response.text });
    } catch (error: any) {
      console.error("Gemini API Error:", error);
      res.status(500).json({ error: error?.message || "An error occurred during link analysis." });
    }
  });

  // Serve static assets or mount Vite middleware depending on environment
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Link Forensics Server] Running on http://localhost:${PORT} in ${process.env.NODE_ENV || "development"} mode`);
  });
}

startServer();
