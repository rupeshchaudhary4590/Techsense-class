export interface CheckResult {
  cat: "structure" | "deception" | "trust" | "urgency" | "delivery";
  pass: boolean;
  weight: number;
  label: string;
  desc: string;
}

export interface ScanResult {
  error: boolean;
  hostname: string;
  url: string;
  checks: CheckResult[];
  score: number;
}

export interface CategoryMeta {
  name: string;
  icon: string;
  color: string;
  angleRange: [number, number];
}
