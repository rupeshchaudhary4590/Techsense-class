import React, { useState, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import { 
  Shield, 
  Terminal, 
  AlertTriangle, 
  CheckCircle, 
  AlertCircle, 
  HelpCircle, 
  Search, 
  ExternalLink, 
  ArrowLeft,
  Cpu,
  Bookmark,
  Info,
  BookOpen
} from "lucide-react";
import LandingView from "./components/LandingView";
import RadarChart from "./components/RadarChart";
import { analyzeURL } from "./utils/scanner";
import { ScanResult, CheckResult } from "./types";

const PRESETS = [
  {
    name: "Standard secure bank link",
    url: "https://www.bankofamerica.com/login/sign-in.go",
    label: "Safe Link"
  },
  {
    name: "Classic typosquatted brand link",
    url: "https://www.paypa1-security.com/update-account",
    label: "Brand Spoofing"
  },
  {
    name: "Subdomain stacking with suspicious extension",
    url: "http://secure.login.verify-identity.paypal-confirm.work/signin",
    label: "Subdomain Stack"
  },
  {
    name: "Look-alike Unicode (Punycode) link",
    url: "https://xn--aple-0nd.com/auth/login",
    label: "Unicode Homograph"
  },
  {
    name: "Bare IP routing with executable payload",
    url: "http://192.168.1.144/update.exe",
    label: "Direct Malware Delivery"
  },
  {
    name: "Open redirect & heavy obfuscation bypass",
    url: "https://www.google.com/url?q=http%3a%2f%2fscam-site.xyz%2flogin%3fuser%3dadmin",
    label: "Open Redirect"
  }
];

const CATEGORIES = {
  structure: { name: "STRUCTURE", icon: "◧", color: "text-[#a78bfa]", bg: "bg-[#a78bfa]/10", border: "border-[#a78bfa]/20" },
  deception: { name: "DECEPTION", icon: "◈", color: "text-[#ff5470]", bg: "bg-[#ff5470]/10", border: "border-[#ff5470]/20" },
  trust:     { name: "TRUST SIGNALS", icon: "◇", color: "text-[#ffb454]", bg: "bg-[#ffb454]/10", border: "border-[#ffb454]/20" },
  urgency:   { name: "URGENCY LANGUAGE", icon: "◆", color: "text-[#43e8b0]", bg: "bg-[#43e8b0]/10", border: "border-[#43e8b0]/20" },
  delivery:  { name: "DELIVERY RISK", icon: "▲", color: "text-[#ff8a3d]", bg: "bg-[#ff8a3d]/10", border: "border-[#ff8a3d]/20" }
};

export default function App() {
  const [showApp, setShowApp] = useState(false);
  const [urlInput, setUrlInput] = useState("");
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  
  // AI Deep Forensic States
  const [aiAnalysis, setAiAnalysis] = useState<string>("");
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // Auto-scan default template on load
  const loadPreset = (url: string) => {
    setUrlInput(url);
    triggerScan(url);
  };

  const triggerScan = async (targetUrl: string) => {
    const trimmed = targetUrl.trim();
    if (!trimmed) return;

    setIsScanning(true);
    setScanResult(null);
    setAiAnalysis("");
    setAiError(null);

    // Dynamic delay for scanning radar feel (900ms)
    setTimeout(async () => {
      const result = analyzeURL(trimmed);
      setScanResult(result);
      setIsScanning(false);

      // Trigger server-side AI Heuristic Explanation API proxy
      setIsAiLoading(true);
      try {
        const response = await fetch("/api/analyze-link", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ url: trimmed }),
        });
        
        if (!response.ok) {
          throw new Error("Failed to reach advanced AI link analysis service.");
        }
        
        const data = await response.json();
        setAiAnalysis(data.analysis || "");
      } catch (err: any) {
        console.error(err);
        setAiError(err?.message || "AI Analysis offline.");
      } finally {
        setIsAiLoading(false);
      }
    }, 900);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    triggerScan(urlInput);
  };

  // Verdict style selectors
  const getVerdictStyles = (score: number) => {
    if (score >= 55) {
      return {
        badgeColor: "text-[#ff5470] bg-[#ff5470]/10 border-[#ff5470]/30",
        verdictTitle: "CRITICAL PHISHING INDICATORS",
        verdictDesc: "This URL contains multiple high-risk structural techniques, brand mimicry, or unsafe file references widely linked to phishing and credential harvesting.",
        icon: <AlertCircle className="w-8 h-8 text-[#ff5470]" />,
        textColor: "text-[#ff5470]"
      };
    } else if (score >= 25) {
      return {
        badgeColor: "text-[#ffb454] bg-[#ffb454]/10 border-[#ffb454]/30",
        verdictTitle: "SUSPICIOUS FLAG SETS",
        verdictDesc: "The URL raises suspicious design triggers. While not definitive, verify sender identity carefully before navigating further.",
        icon: <AlertTriangle className="w-8 h-8 text-[#ffb454]" />,
        textColor: "text-[#ffb454]"
      };
    } else {
      return {
        badgeColor: "text-[#43e8b0] bg-[#43e8b0]/10 border-[#43e8b0]/30",
        verdictTitle: "LOW STRUCTURAL RISK",
        verdictDesc: "The URL parameters appear standard, with secure protocols and no registered brand imitation characteristics.",
        icon: <CheckCircle className="w-8 h-8 text-[#43e8b0]" />,
        textColor: "text-[#43e8b0]"
      };
    }
  };

  return (
    <>
      {!showApp ? (
        <LandingView onEnter={() => setShowApp(true)} />
      ) : (
        <div className="min-h-screen bg-[#08070d] text-[#ece8f7] relative pb-16 font-sans">
          {/* Subtle upper background glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[300px] bg-gradient-to-b from-[#1c1530]/50 to-transparent pointer-events-none select-none" />

          {/* Core Content Wrap */}
          <div className="max-w-6xl mx-auto px-4 pt-8 relative z-10">
            {/* Header / Forensics Nav Strip */}
            <div className="flex items-center justify-between border-b border-[#1d1930] pb-6 mb-8">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowApp(false)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#0f0d19] border border-[#2a2440] hover:border-[#a78bfa] hover:text-[#a78bfa] text-xs font-mono transition-all duration-200 select-none cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> BACK TO TERMINAL
                </button>
                <div className="hidden sm:flex items-center gap-2 text-[10px] font-mono text-[#524a72] select-none uppercase tracking-widest">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#43e8b0]" /> CASE LOG // TECHSENSE PRESENTATION MODE
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs font-mono text-[#8b84a8] select-none">
                <span>VER: 3.1_RELEASE</span>
              </div>
            </div>

            {/* Intro Title */}
            <div className="mb-8">
              <h1 className="text-3xl font-display font-extrabold tracking-wider text-white uppercase flex items-center gap-2 select-none">
                phish<span className="text-[#a78bfa]">·</span>scan <span className="text-xs font-mono px-2 py-0.5 bg-[#2a2440] rounded text-[#a78bfa] align-middle tracking-widest font-normal">SECURE FORENSICS</span>
              </h1>
              <p className="text-[#8b84a8] text-sm max-w-2xl mt-1.5">
                Paste any web address to decode structural threats, brand impersonations, urgency keywords, and delivery vectors. Analyze link patterns fully client-isolated, plus invoke AI heuristics.
              </p>
            </div>

            {/* Dashboard Layout Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* LEFT: Controls, Subject, Verdict, Heuristics (Col span: 7) */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* Dossier Input Card */}
                <div className="bg-[#0f0d19] border border-[#2a2440] rounded-xl p-5 shadow-lg relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-1 bg-gradient-to-r from-[#a78bfa] to-[#ff5470]" />
                  
                  <div className="text-[10px] font-mono text-[#524a72] uppercase tracking-wider mb-2.5 flex items-center gap-1.5 select-none">
                    <Terminal className="w-3.5 h-3.5 text-[#a78bfa]" /> SUBJECT TARGET LINK DISCOVERY
                  </div>

                  <form onSubmit={handleFormSubmit} className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#524a72]" />
                      <input
                        type="text"
                        value={urlInput}
                        onChange={(e) => setUrlInput(e.target.value)}
                        placeholder="e.g. www.paypa1-security.com/update-password"
                        className="w-full bg-[#08070d] border border-[#1d1930] rounded-lg pl-11 pr-4 py-3 text-sm font-mono text-[#ece8f7] placeholder-[#524a72] outline-none focus:border-[#a78bfa] transition-all duration-200"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={isScanning || !urlInput.trim()}
                      className="px-6 bg-[#a78bfa] hover:bg-[#a78bfa]/90 active:scale-95 disabled:opacity-30 disabled:scale-100 disabled:cursor-not-allowed text-[#08070d] font-mono text-sm font-bold rounded-lg transition-all duration-150 cursor-pointer"
                    >
                      {isScanning ? "SCANNING..." : "SCAN"}
                    </button>
                  </form>

                  {/* Sandboxed Interactive Presets */}
                  <div className="mt-4 pt-4 border-t border-[#1d1930]">
                    <div className="text-[10px] font-mono text-[#8b84a8] uppercase tracking-wider mb-2.5 flex items-center gap-1">
                      <BookOpen className="w-3 h-3 text-[#ffb454]" /> PRESENTATION SANDBOX PRESETS (CLICK TO LIVE ANALYZE)
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {PRESETS.map((preset, index) => (
                        <button
                          key={index}
                          type="button"
                          onClick={() => loadPreset(preset.url)}
                          className="px-2.5 py-1.5 rounded-md bg-[#171325] border border-[#1d1930] hover:border-[#a78bfa]/50 text-[11px] font-mono text-left transition-all text-[#8b84a8] hover:text-[#ece8f7] cursor-pointer"
                        >
                          <div className="font-bold text-[#a78bfa] text-[10px] leading-tight select-none">
                            {preset.label}
                          </div>
                          <div className="text-[10px] text-[#524a72] truncate max-w-[170px]">
                            {preset.name}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Verdict Summary Card */}
                {scanResult && !isScanning && (
                  <div className="bg-[#0f0d19] border border-[#2a2440] rounded-xl p-5 shadow-lg flex flex-col md:flex-row gap-5 items-start md:items-center animate-[scaleIn_0.35s_ease_forwards]">
                    {/* Circle Score block */}
                    <div className="flex flex-col items-center justify-center p-4 bg-[#08070d] border border-[#1d1930] rounded-lg min-w-[100px] self-stretch md:self-auto text-center">
                      <span className={`text-4xl font-mono font-bold ${getVerdictStyles(scanResult.score).textColor}`}>
                        {scanResult.score}
                      </span>
                      <span className="text-[9px] font-mono text-[#524a72] uppercase tracking-widest mt-1">
                        RISK INDEX
                      </span>
                    </div>

                    {/* Verdict content */}
                    <div className="flex-1 space-y-1.5">
                      <div className="flex items-center gap-2">
                        <div className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border tracking-wider uppercase ${getVerdictStyles(scanResult.score).badgeColor}`}>
                          {getVerdictStyles(scanResult.score).verdictTitle}
                        </div>
                      </div>
                      <h3 className="text-md font-display font-semibold text-white uppercase tracking-wide">
                        {scanResult.score >= 55 ? "Malicious indicators detected" : scanResult.score >= 25 ? "Suspicious elements noted" : "Clean structural results"}
                      </h3>
                      <p className="text-xs text-[#8b84a8] leading-relaxed">
                        {getVerdictStyles(scanResult.score).verdictDesc}
                      </p>
                    </div>
                  </div>
                )}

                {/* ADVANCED AI FORENSIC ANALYSIS BLOCK */}
                {scanResult && !isScanning && (
                  <div className="bg-[#0f0d19] border border-[#2a2440] rounded-xl overflow-hidden shadow-lg animate-[scaleIn_0.4s_ease_forwards]">
                    <div className="bg-[#171325] px-5 py-3 border-b border-[#2a2440] flex justify-between items-center select-none">
                      <div className="flex items-center gap-2">
                        <Cpu className="w-4 h-4 text-[#a78bfa] animate-pulse" />
                        <span className="text-xs font-display font-bold text-white tracking-wider uppercase">
                          AI Deep-Forensics Explainer
                        </span>
                      </div>
                      <span className="text-[9px] font-mono text-[#8b84a8] bg-[#08070d] px-2 py-0.5 rounded border border-[#1d1930] tracking-wider uppercase">
                        GEMINI 3.5 FLASH ENGAGED
                      </span>
                    </div>

                    <div className="p-5 space-y-4">
                      {isAiLoading ? (
                        <div className="py-6 flex flex-col items-center justify-center space-y-3">
                          <div className="w-8 h-8 rounded-full border-t-2 border-b-2 border-[#a78bfa] animate-spin" />
                          <p className="text-xs font-mono text-[#8b84a8] tracking-widest uppercase animate-pulse">
                            Consulting Heuristic Threat Engine...
                          </p>
                        </div>
                      ) : aiError ? (
                        <div className="p-3 bg-[#ff5470]/5 border border-[#ff5470]/20 rounded-lg flex gap-3 text-xs text-[#ff5470]">
                          <AlertCircle className="w-4 h-4 flex-shrink-0" />
                          <div>
                            <span className="font-bold">Error:</span> {aiError}
                          </div>
                        </div>
                      ) : (
                        <div className="prose prose-invert prose-xs max-w-none text-xs text-[#ece8f7] font-mono leading-relaxed space-y-2">
                          <ReactMarkdown
                            components={{
                              h3: ({ node, ...props }) => <h3 className="text-sm font-semibold text-[#a78bfa] font-display mt-3 uppercase tracking-wider border-b border-[#1d1930] pb-1" {...props} />,
                              strong: ({ node, ...props }) => <strong className="text-white font-bold" {...props} />,
                              p: ({ node, ...props }) => <p className="mb-2 last:mb-0 leading-relaxed text-[#8b84a8]" {...props} />,
                              li: ({ node, ...props }) => <li className="list-disc list-inside ml-2 text-[#8b84a8]" {...props} />,
                              ul: ({ node, ...props }) => <ul className="my-2 space-y-1" {...props} />
                            }}
                          >
                            {aiAnalysis}
                          </ReactMarkdown>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* RIGHT: Active Radar visualization, checks (Col span: 5) */}
              <div className="lg:col-span-5 flex flex-col items-center space-y-6">
                
                {/* Visualizer Frame */}
                <div className="bg-[#0f0d19] border border-[#2a2440] rounded-xl p-5 shadow-lg w-full flex flex-col items-center">
                  <div className="text-[10px] font-mono text-[#524a72] uppercase tracking-wider mb-5 self-start select-none">
                    🛡 ACTIVE THREAT RECOGNITION PLOT
                  </div>

                  <RadarChart 
                    checks={scanResult ? scanResult.checks : []} 
                    active={isScanning} 
                    score={scanResult ? scanResult.score : 0} 
                  />

                  {/* Indicator Tiers */}
                  <div className="w-full grid grid-cols-3 gap-2 mt-6 pt-5 border-t border-[#1d1930] text-center select-none">
                    <div>
                      <div className="text-xs font-mono font-bold text-[#43e8b0]">
                        0 - 24
                      </div>
                      <div className="text-[9px] font-mono text-[#524a72] uppercase">
                        Low Risk
                      </div>
                    </div>
                    <div className="border-x border-[#1d1930]">
                      <div className="text-xs font-mono font-bold text-[#ffb454]">
                        25 - 54
                      </div>
                      <div className="text-[9px] font-mono text-[#524a72] uppercase">
                        Suspicious
                      </div>
                    </div>
                    <div>
                      <div className="text-xs font-mono font-bold text-[#ff5470]">
                        55+
                      </div>
                      <div className="text-[9px] font-mono text-[#524a72] uppercase">
                        High Threat
                      </div>
                    </div>
                  </div>
                </div>

                {/* Legend Details */}
                <div className="bg-[#0f0d19] border border-[#2a2440] rounded-xl p-4 shadow-md w-full text-xs space-y-2 font-mono">
                  <div className="text-[10px] text-[#524a72] uppercase tracking-wider mb-2.5 select-none">
                    CHART INTERPRETATION
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="text-[#43e8b0]">🟢</span>
                    <div>
                      <strong className="text-white">Clean indicators</strong> are plotted on the far outer edge (Radius 118) indicating no threat vectors detected in that category.
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="text-[#a78bfa]">🟡</span>
                    <div>
                      <strong className="text-white">Risk alerts</strong> map closer to the absolute center depending on the threat weight of the rule they trigger.
                    </div>
                  </div>
                </div>

              </div>

            </div>

            {/* LOWER PORTION: FULL CRITERIA BREAKDOWN */}
            {scanResult && !isScanning && (
              <div className="mt-8 bg-[#0f0d19] border border-[#2a2440] rounded-xl overflow-hidden shadow-lg animate-[scaleIn_0.45s_ease_forwards]">
                <div className="bg-[#171325] px-5 py-4 border-b border-[#2a2440] flex justify-between items-center select-none">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-[#ffb454]" />
                    <span className="text-xs font-display font-bold text-white tracking-wider uppercase">
                      17 COMPREHENSIVE HEURISTIC CHECKS BREAKDOWN
                    </span>
                  </div>
                </div>

                <div className="p-5 space-y-6">
                  {/* Category lists */}
                  {Object.entries(CATEGORIES).map(([catKey, catMeta]) => {
                    const catChecks = scanResult.checks.filter(c => c.cat === catKey);
                    const failedCount = catChecks.filter(c => !c.pass).length;
                    
                    return (
                      <div key={catKey} className="border border-[#1d1930] rounded-lg overflow-hidden bg-[#0a0912]">
                        {/* Subheader */}
                        <div className="px-4 py-3 bg-[#0f0d19] border-b border-[#1d1930] flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className={`font-mono text-sm ${catMeta.color}`}>
                              {catMeta.icon}
                            </span>
                            <span className="text-xs font-mono font-bold tracking-widest text-white">
                              {catMeta.name}
                            </span>
                          </div>
                          <span className="text-[10px] font-mono text-[#524a72] uppercase">
                            {failedCount} alert{failedCount === 1 ? "" : "s"} / {catChecks.length} rules
                          </span>
                        </div>

                        {/* Rules table */}
                        <div className="divide-y divide-[#1d1930]/40">
                          {catChecks.map((item, idx) => {
                            let tagColor = "text-[#43e8b0] bg-[#43e8b0]/5 border-[#43e8b0]/10";
                            let tagLabel = "CLEAN";
                            if (!item.pass) {
                              if (item.weight >= 20) {
                                tagColor = "text-[#ff5470] bg-[#ff5470]/5 border-[#ff5470]/10";
                                tagLabel = "CRITICAL";
                              } else {
                                tagColor = "text-[#ffb454] bg-[#ffb454]/5 border-[#ffb454]/10";
                                tagLabel = "ALERT";
                              }
                            }

                            return (
                              <div key={idx} className="p-4 flex flex-col sm:flex-row sm:items-center gap-3">
                                <div className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold border tracking-wider text-center self-start sm:self-auto ${tagColor}`}>
                                  {tagLabel}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <h4 className="text-xs font-semibold text-[#ece8f7] flex items-center gap-2">
                                    {item.label}
                                    {!item.pass && (
                                      <span className="text-[10px] font-mono text-[#ffb454] font-normal">
                                        (+{item.weight} severity weight)
                                      </span>
                                    )}
                                  </h4>
                                  <p className="text-xs text-[#8b84a8] mt-1 leading-relaxed">
                                    {item.desc}
                                  </p>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* CLASSROOM FOOTNOTE DISCLAIMER */}
            <div className="mt-8 pt-6 border-t border-[#1d1930] text-[11px] font-mono text-[#524a72] leading-relaxed select-none">
              <div className="flex items-center gap-1.5 font-bold mb-1.5 text-[#8b84a8]">
                <Info className="w-3.5 h-3.5" /> SECURITY EDUCATIONAL NOTICE // TECHSENSE PRESENTATION DEBRIEFING
              </div>
              <div>
                <strong>Heuristic Limitations:</strong> This model analyzes URL strings based on standard visual deceptive tactics (Homographs, Typosquats, Obfuscation, and Urgent keyword sequences). It does not verify live web assets, query sandbox blocklists, or track active malicious redirects. Standard, low-scoring URLs should still be handled with appropriate access hygiene. Never enter credentials into unrecognized landing domains.
              </div>
            </div>

          </div>
        </div>
      )}
    </>
  );
}
