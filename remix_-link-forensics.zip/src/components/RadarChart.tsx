import React, { useEffect, useState } from "react";
import { CheckResult, CategoryMeta } from "../types";

interface RadarChartProps {
  checks: CheckResult[];
  active: boolean;
  score: number;
}

const CATEGORIES: Record<string, CategoryMeta> = {
  structure: { name: "STRUCTURE", icon: "◧", color: "#a78bfa", angleRange: [0, 56] },
  deception: { name: "DECEPTION", icon: "◈", color: "#ff5470", angleRange: [72, 128] },
  trust:     { name: "TRUST SIGNALS", icon: "◇", color: "#ffb454", angleRange: [144, 200] },
  urgency:   { name: "URGENCY LANGUAGE", icon: "◆", color: "#43e8b0", angleRange: [216, 256] },
  delivery:  { name: "DELIVERY RISK", icon: "▲", color: "#ff8a3d", angleRange: [272, 344] }
};

const CAT_ORDER = ["structure", "deception", "trust", "urgency", "delivery"];

function polarToXY(cx: number, cy: number, r: number, angleDeg: number) {
  const rad = ((angleDeg - 90) * Math.PI) / 180;
  return {
    x: cx + r * Math.cos(rad),
    y: cy + r * Math.sin(rad),
  };
}

export default function RadarChart({ checks, active, score }: RadarChartProps) {
  const [renderedBlips, setRenderedBlips] = useState<Array<{
    x: number;
    y: number;
    color: string;
    isPass: boolean;
    weight: number;
    label: string;
    delay: number;
  }>>([]);

  const cx = 140;
  const cy = 140;

  useEffect(() => {
    if (checks.length === 0) {
      setRenderedBlips([]);
      return;
    }

    const grouped: Record<string, CheckResult[]> = {};
    CAT_ORDER.forEach((c) => (grouped[c] = []));
    checks.forEach((c) => {
      if (grouped[c.cat]) {
        grouped[c.cat].push(c);
      }
    });

    const blipsList: typeof renderedBlips = [];
    let cumulativeDelay = 0;

    CAT_ORDER.forEach((catKey) => {
      const items = grouped[catKey] || [];
      const meta = CATEGORIES[catKey];
      if (!meta) return;

      const [aStart, aEnd] = meta.angleRange;
      const catColor = meta.color;

      items.forEach((item, idx) => {
        // Distribute within angle range
        const angle =
          items.length === 1
            ? (aStart + aEnd) / 2
            : aStart + ((aEnd - aStart) * idx) / (items.length - 1);

        // Map risk weight to distance from center (higher weight/failure = closer to center)
        // If passed: plot on the outer ring (radius ~ 118)
        // If failed: plot closer in (radius depending on severity, min 32, max 100)
        const radius = item.pass
          ? 118
          : Math.max(32, 118 - (item.weight / 35) * 85);

        const { x, y } = polarToXY(cx, cy, radius, angle);
        const color = item.pass ? "#43e8b0" : catColor;

        blipsList.push({
          x,
          y,
          color,
          isPass: item.pass,
          weight: item.weight,
          label: item.label,
          delay: cumulativeDelay,
        });

        cumulativeDelay += 60;
      });
    });

    setRenderedBlips(blipsList);
  }, [checks]);

  // Determine indicator color
  const statusColor =
    score >= 55 ? "text-[#ff5470]" : score >= 25 ? "text-[#ffb454]" : "text-[#43e8b0]";

  return (
    <div className="relative w-[280px] h-[280px] bg-[#0f0d19] border border-[#2a2440] rounded-full p-2 shadow-2xl flex items-center justify-center select-none">
      <svg viewBox="0 0 280 280" className="w-full h-full overflow-visible">
        {/* Radar concentric rings */}
        <circle className="stroke-[#1d1930] fill-none stroke-[1]" cx="140" cy="140" r="30" />
        <circle className="stroke-[#1d1930] fill-none stroke-[1]" cx="140" cy="140" r="65" />
        <circle className="stroke-[#1d1930] fill-none stroke-[1]" cx="140" cy="140" r="100" />
        <circle className="stroke-[#1d1930] fill-none stroke-[1]" cx="140" cy="140" r="130" />

        {/* Radar Crosshairs */}
        <line className="stroke-[#1d1930] stroke-[1]" x1="140" y1="10" x2="140" y2="270" />
        <line className="stroke-[#1d1930] stroke-[1]" x1="10" y1="140" x2="270" y2="140" />

        {/* Division markers / boundaries */}
        {CAT_ORDER.map((catKey) => {
          const meta = CATEGORIES[catKey];
          const [aStart] = meta.angleRange;
          const p = polarToXY(cx, cy, 134, aStart);
          return (
            <line
              key={catKey}
              className="stroke-[#2a2440] stroke-[1] stroke-dasharray-[2_4]"
              x1="140"
              y1="140"
              x2={p.x}
              y2={p.y}
              strokeDasharray="2 4"
            />
          );
        })}

        {/* Sweep rotation animation */}
        <g
          className={`origin-[140px_140px] transition-opacity duration-300 ${
            active ? "opacity-100 animate-[spin_3.2s_linear_infinite]" : "opacity-20"
          }`}
          style={{ transformOrigin: "140px 140px" }}
        >
          <defs>
            <linearGradient id="sweepGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#a78bfa" stopOpacity="0" />
              <stop offset="100%" stopColor="#a78bfa" stopOpacity="0.3" />
            </linearGradient>
          </defs>
          <path d="M140,140 L140,10 A130,130 0 0,1 253,90 Z" fill="url(#sweepGrad)" />
        </g>

        {/* Rendered Blips */}
        {renderedBlips.map((blip, index) => {
          return (
            <g
              key={index}
              className="animate-[scaleIn_0.4s_ease_forwards]"
              style={{
                animationDelay: `${blip.delay}ms`,
                transformOrigin: `${blip.x}px ${blip.y}px`,
                opacity: 0,
              }}
            >
              {/* Failed/Suspect blip ripple animation */}
              {!blip.isPass && (
                <circle
                  cx={blip.x}
                  cy={blip.y}
                  r="5"
                  fill={blip.color}
                  className="animate-ping opacity-70"
                />
              )}
              {/* Inner core dot */}
              <circle
                cx={blip.x}
                cy={blip.y}
                r={blip.isPass ? 3.5 : 5.5}
                fill={blip.color}
                stroke="#08070d"
                strokeWidth="1.5"
                className="hover:scale-150 transition-transform cursor-pointer"
              >
                <title>{`${blip.label} (${blip.isPass ? "Clean" : `Risk weight: ${blip.weight}`})`}</title>
              </circle>
            </g>
          );
        })}
      </svg>

      {/* Radar absolute center display readout */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none max-w-[150px]">
        {active ? (
          <div className="text-[10px] font-mono text-[#a78bfa] uppercase tracking-widest animate-pulse">
            SCANNING...
          </div>
        ) : checks.length > 0 ? (
          <div className="space-y-0.5">
            <div className={`text-2xl font-mono font-bold tracking-tight ${statusColor}`}>
              {score}
            </div>
            <div className="text-[9px] font-mono text-[#8b84a8] tracking-wider uppercase">
              RISK INDEX
            </div>
          </div>
        ) : (
          <div className="text-[10px] font-mono text-[#524a72] uppercase tracking-widest animate-pulse leading-snug">
            AWAITING<br />LINK SUBJECT
          </div>
        )}
      </div>

      <style>{`
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>
  );
}
