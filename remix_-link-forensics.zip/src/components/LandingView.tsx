import { useState, useEffect } from "react";
import { Shield, Terminal, Zap } from "lucide-react";

interface LandingViewProps {
  onEnter: () => void;
}

export default function LandingView({ onEnter }: LandingViewProps) {
  const [typedLines, setTypedLines] = useState<string[]>([]);
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const [currentCharIndex, setCurrentCharIndex] = useState(0);
  const [isReady, setIsReady] = useState(false);

  const logs = [
    "> INITIATING LINK FORENSIC CORE v3.1...",
    "> LOADING 17 COMPREHENSIVE RECOGNITION RULES...",
    "> CATEGORIES ACTIVE: STRUCTURE // DECEPTION // TRUST // URGENCY // DELIVERY...",
    "> STANDALONE LOCAL EXECUTION ENGAGED // PRIVACY-SECURED...",
    "> SYSTEMS ONLINE. READY."
  ];

  useEffect(() => {
    if (currentLineIndex >= logs.length) {
      setIsReady(true);
      return;
    }

    const currentLine = logs[currentLineIndex];
    if (currentCharIndex <= currentLine.length) {
      const timeout = setTimeout(() => {
        setTypedLines((prev) => {
          const next = [...prev];
          next[currentLineIndex] = currentLine.slice(0, currentCharIndex);
          return next;
        });
        setCurrentCharIndex((prev) => prev + 1);
      }, currentLineIndex === logs.length - 1 ? 25 : 15);
      return () => clearTimeout(timeout);
    } else {
      const timeout = setTimeout(() => {
        setCurrentLineIndex((prev) => prev + 1);
        setCurrentCharIndex(0);
      }, 250);
      return () => clearTimeout(timeout);
    }
  }, [currentLineIndex, currentCharIndex]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#08070d] text-[#ece8f7] overflow-hidden">
      {/* Dynamic Grid Background */}
      <div 
        className="absolute inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(#1a1628 1px, transparent 1px),
            linear-gradient(90deg, #1a1628 1px, transparent 1px)
          `,
          backgroundSize: "42px 42px",
          maskImage: "radial-gradient(ellipse 600px 460px at 50% 45%, #000 20%, transparent 75%)",
          WebkitMaskImage: "radial-gradient(ellipse 600px 460px at 50% 45%, #000 20%, transparent 75%)",
        }}
      />

      <div className="relative z-10 text-center px-6 max-w-xl w-full flex flex-col items-center">
        {/* Network status badge */}
        <div className="flex items-center gap-2 px-3 py-1 bg-[#171325] border border-[#2a2440] rounded-full text-xs font-mono text-[#8b84a8] tracking-widest mb-6 uppercase select-none">
          <span className="w-2 h-2 rounded-full bg-[#43e8b0] shadow-[0_0_8px_#43e8b0] animate-pulse" />
          SYSTEM SECURERADAR ACTIVE
        </div>

        {/* Display Title */}
        <h1 className="text-4xl sm:text-5xl font-display font-extrabold tracking-[4px] leading-none mb-4 select-none uppercase">
          LINK <span className="bg-gradient-to-r from-[#a78bfa] to-[#ff5470] bg-clip-text text-transparent">FORENSICS</span>
          <span className="text-[#a78bfa]">.</span>
        </h1>

        <p className="text-sm font-mono text-[#8b84a8] mb-8 max-w-sm select-none">
          Rule-based, offline cyberthreat link intelligence for standard and advanced URL inspection.
        </p>

        {/* Typing Console Log */}
        <div className="w-full bg-[#0f0d19] border border-[#2a2440] rounded-lg p-5 font-mono text-left text-xs text-[#43e8b0] mb-8 shadow-inner min-h-[160px] flex flex-col justify-between">
          <div className="space-y-2">
            {typedLines.map((line, idx) => (
              <div key={idx} className="leading-relaxed whitespace-pre-wrap">
                {line}
              </div>
            ))}
            {!isReady && (
              <span className="inline-block w-2 h-4 bg-[#43e8b0] animate-pulse ml-1 align-middle" />
            )}
          </div>
          {isReady && (
            <div className="text-[#8b84a8] text-[10px] border-t border-[#1d1930] pt-2 mt-4 flex justify-between items-center select-none">
              <span>RULESET v3.1_RELEASE</span>
              <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> CLIENT SECURED</span>
            </div>
          )}
        </div>

        {/* Entering Action Button */}
        <button
          onClick={onEnter}
          disabled={!isReady}
          className={`relative group px-8 py-4 bg-[#a78bfa] text-[#08070d] font-display font-bold text-sm tracking-[2px] rounded-lg select-none uppercase shadow-lg shadow-[#a78bfa]/20 active:scale-95 transition-all duration-300 ${
            isReady 
              ? "opacity-100 translate-y-0 cursor-pointer hover:shadow-[#a78bfa]/40" 
              : "opacity-40 translate-y-4 cursor-not-allowed"
          }`}
        >
          <span className="absolute inset-0 w-full h-full rounded-lg bg-white/20 scale-0 group-hover:scale-100 transition-transform duration-300 origin-center" />
          <span className="flex items-center gap-2 justify-center">
            LAUNCH RADAR ANALYSIS <ArrowRightIcon className="w-4 h-4" />
          </span>
        </button>

        <div className="mt-6 text-[10px] font-mono text-[#524a72] select-none">
          17 Rule Heuristics • Client-isolated execution • Crafted for TechSense presentation
        </div>
      </div>
    </div>
  );
}

function ArrowRightIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M5 12h14" />
      <path d="m12 5 7 7-7 7" />
    </svg>
  );
}
