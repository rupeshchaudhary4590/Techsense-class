import { CheckResult, ScanResult } from "../types";

const KNOWN_BRANDS = [
  "google",
  "facebook",
  "paypal",
  "apple",
  "microsoft",
  "amazon",
  "netflix",
  "instagram",
  "whatsapp",
  "bankofamerica",
  "wellsfargo",
  "chase",
  "dropbox",
  "linkedin",
  "yahoo",
  "outlook",
  "icloud",
  "binance",
  "coinbase",
  "ebay",
  "adobe",
  "github",
  "esewa",
  "khalti",
  "nabilbank",
  "nicasiabank",
  "nmb",
  "nepalbank",
];

const SHORTENERS = [
  "bit.ly",
  "tinyurl.com",
  "t.co",
  "goo.gl",
  "ow.ly",
  "is.gd",
  "buff.ly",
  "rebrand.ly",
  "cutt.ly",
  "shorte.st",
  "tiny.cc",
  "rb.gy",
  "bl.ink",
];

const SUSPICIOUS_TLDS = [
  "zip",
  "mov",
  "xyz",
  "top",
  "click",
  "link",
  "gq",
  "tk",
  "ml",
  "cf",
  "ga",
  "work",
  "country",
  "kim",
  "review",
  "ru",
];

function levenshtein(a: string, b: string): number {
  const dp = Array.from({ length: a.length + 1 }, () =>
    new Array(b.length + 1).fill(0)
  );
  for (let i = 0; i <= a.length; i++) dp[i][0] = i;
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;

  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] =
        a[i - 1] === b[j - 1]
          ? dp[i - 1][j - 1]
          : 1 + Math.min(dp[i - 1][j - 1], dp[i - 1][j], dp[i][j - 1]);
    }
  }
  return dp[a.length][b.length];
}

export function analyzeURL(raw: string): ScanResult {
  const checks: CheckResult[] = [];
  let hostname = "";
  let pathname = "";
  let search = "";
  let protocol = "";
  let parsed: URL | null = null;
  let candidate = raw.trim();

  // Handle lack of protocol
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(candidate)) {
    candidate = "http://" + candidate;
  }

  try {
    parsed = new URL(candidate);
    hostname = parsed.hostname.toLowerCase();
    pathname = parsed.pathname.toLowerCase();
    search = parsed.search.toLowerCase();
    protocol = parsed.protocol.replace(":", "");
  } catch (e) {
    return {
      error: true,
      hostname: raw,
      url: raw,
      checks: [
        {
          cat: "structure",
          pass: false,
          weight: 35,
          label: "Could not parse URL",
          desc: "This text does not form a valid URL structure. Phishing links rely on browser parsing, which would likely fail here or redirect unexpectedly.",
        },
      ],
      score: 70,
    };
  }

  const hostParts = hostname.split(".");
  const registrable = hostParts.length >= 2 ? hostParts[hostParts.length - 2] : hostname;

  // 1. STRUCTURE CHECKS
  const ipPattern = /^(\d{1,3}\.){3}\d{1,3}$/;
  if (ipPattern.test(hostname)) {
    checks.push({
      cat: "structure",
      pass: false,
      weight: 25,
      label: "Raw IP address as host",
      desc: "Bare IP addresses (e.g., 192.168.1.1) bypass domain registrars and are heavily used in low-cost automated phishing campaigns.",
    });
  } else {
    checks.push({
      cat: "structure",
      pass: true,
      weight: 0,
      label: "Host is a registered domain name",
      desc: "The host is not a raw IP, meaning it has a name registered under a DNS suffix.",
    });
  }

  if (hostname.includes("xn--")) {
    checks.push({
      cat: "structure",
      pass: false,
      weight: 20,
      label: "Punycode domain (unicode mimic)",
      desc: "Punycode (starts with xn--) indicates the domain uses non-Latin scripts. Attackers use this to display characters that are visually identical to standard characters (homoglyphs).",
    });
  } else {
    checks.push({
      cat: "structure",
      pass: true,
      weight: 0,
      label: "Standard character set",
      desc: "No unicode punycode or homoglyph character masks detected.",
    });
  }

  const subCount = Math.max(0, hostParts.length - 2);
  if (subCount >= 3) {
    checks.push({
      cat: "structure",
      pass: false,
      weight: 15,
      label: `Excessive subdomains (${hostParts.length} parts)`,
      desc: `Found ${hostParts.length} domain layers. Attackers use long subdomain chains to pack fake brand names (e.g., pay-paypal.secure.com-update.ru) while the real domain sits at the very end.`,
    });
  } else {
    checks.push({
      cat: "structure",
      pass: true,
      weight: 0,
      label: "Normal domain nesting depth",
      desc: "Subdomain hierarchy is standard and does not appear stacked to bury the master domain.",
    });
  }

  const hyphenCount = (registrable.match(/-/g) || []).length;
  if (hyphenCount >= 2) {
    checks.push({
      cat: "structure",
      pass: false,
      weight: 10,
      label: "Excessive hyphens in primary domain",
      desc: "Attackers often insert multiple hyphens (e.g., login-security-paypal-update) when the exact targeted domain name is already taken.",
    });
  } else {
    checks.push({
      cat: "structure",
      pass: true,
      weight: 0,
      label: "Standard hyphenation",
      desc: "The primary domain name has minimal or no hyphen characters.",
    });
  }

  if (raw.length > 90) {
    checks.push({
      cat: "structure",
      pass: false,
      weight: 8,
      label: "Suspiciously long URL",
      desc: `URL is ${raw.length} characters long. Extremely long links are often crafted to push the real registered domain out of the visible address bar in mobile browser viewports.`,
    });
  } else {
    checks.push({
      cat: "structure",
      pass: true,
      weight: 0,
      label: "Standard URL length",
      desc: "URL length falls within the standard parameters of web navigation.",
    });
  }

  // 2. DECEPTION CHECKS
  if (raw.includes("@")) {
    checks.push({
      cat: "deception",
      pass: false,
      weight: 25,
      label: "Contains '@' symbol redirection trick",
      desc: "Browsers treat everything before an '@' symbol in the host segment as username credentials, routing purely to the address after it. Phishers use this to trick users with URLs like 'paypal.com@scam-site.com'.",
    });
  } else {
    checks.push({
      cat: "deception",
      pass: true,
      weight: 0,
      label: "No '@' routing obfuscation",
      desc: "The URL does not contain username authorization separators.",
    });
  }

  let typosquat: { brand: string; dist: number } | null = null;
  for (const brand of KNOWN_BRANDS) {
    if (registrable === brand) continue;
    const dist = levenshtein(registrable, brand);
    if (dist > 0 && dist <= 2 && Math.abs(registrable.length - brand.length) <= 2 && brand.length >= 4) {
      typosquat = { brand, dist };
      break;
    }
  }

  if (typosquat) {
    checks.push({
      cat: "deception",
      pass: false,
      weight: 30,
      label: `Typosquatting alert: closely matches "${typosquat.brand}"`,
      desc: `"${registrable}" is highly similar to the popular trademark "${typosquat.brand}" (Levenshtein distance: ${typosquat.dist}). This is a classic brand-spoofing technique.`,
    });
  } else {
    checks.push({
      cat: "deception",
      pass: true,
      weight: 0,
      label: "No major brand typosquatting detected",
      desc: "The primary registrable domain name does not closely mimic any heavily targeted major brands.",
    });
  }

  // 3. TRUST SIGNALS
  if (protocol !== "https") {
    checks.push({
      cat: "trust",
      pass: false,
      weight: 15,
      label: "Insecure protocol (Plain HTTP)",
      desc: "The link uses HTTP instead of encrypted HTTPS. While HTTPS is cheap and easily available, phishing links on bulk servers frequently fall back to standard HTTP.",
    });
  } else {
    checks.push({
      cat: "trust",
      pass: true,
      weight: 0,
      label: "Secured protocol (HTTPS)",
      desc: "The connection uses HTTPS, which protects in-transit data from snooping (though a phisher can still host over HTTPS).",
    });
  }

  const tld = hostParts[hostParts.length - 1];
  if (SUSPICIOUS_TLDS.includes(tld)) {
    checks.push({
      cat: "trust",
      pass: false,
      weight: 10,
      label: `High-abuse TLD (.${tld})`,
      desc: `Top-Level Domains like .${tld} are extremely cheap, offer anonymous registration, and feature lax abuse-reporting oversight. They are heavily populated by spam campaigns.`,
    });
  } else {
    checks.push({
      cat: "trust",
      pass: true,
      weight: 0,
      label: "Trusted TLD registry",
      desc: `The .${tld} TLD is standard and not heavily correlated with quick-throwaway phishing domains.`,
    });
  }

  if (SHORTENERS.some((s) => hostname === s || hostname.endsWith("." + s))) {
    checks.push({
      cat: "trust",
      pass: false,
      weight: 15,
      label: "Link shortener service used",
      desc: "The link has been compressed by a shortening service. This hides the actual domain and path from simple previews, a tactic widely used to slip bad links past secure firewalls.",
    });
  } else {
    checks.push({
      cat: "trust",
      pass: true,
      weight: 0,
      label: "Direct web link",
      desc: "The link points directly to the hosting server, keeping its final path and domain fully transparent.",
    });
  }

  // 4. URGENCY
  const keywords = [
    "login",
    "verify",
    "secure",
    "account",
    "update",
    "confirm",
    "signin",
    "password",
    "banking",
    "bank",
    "suspended",
    "unlock",
  ];
  const hitKeywords = keywords.filter(
    (k) => pathname.includes(k) || search.includes(k) || hostname.includes(k)
  );

  if (hitKeywords.length >= 2) {
    checks.push({
      cat: "urgency",
      pass: false,
      weight: 15,
      label: `Urgency keyword stacking (${hitKeywords.length} hits)`,
      desc: `Found urgent keywords: [${[...new Set(hitKeywords)].join(", ")}]. Attackers load URLs with these triggers to induce immediate action and fear.`,
    });
  } else if (hitKeywords.length === 1) {
    checks.push({
      cat: "urgency",
      pass: false,
      weight: 5,
      label: `Contains security keyword: "${hitKeywords[0]}"`,
      desc: "An account-related trigger word was found. While standard for many clean pages, context is key.",
    });
  } else {
    checks.push({
      cat: "urgency",
      pass: true,
      weight: 0,
      label: "No urgent/credential keywords found",
      desc: "No high-panic vocabulary (login, verify, suspend, banking) is loaded in the path, query, or subdomains.",
    });
  }

  // 5. DELIVERY RISK
  if (["javascript", "data", "vbscript", "file"].includes(protocol)) {
    checks.push({
      cat: "delivery",
      pass: false,
      weight: 35,
      label: `Active execution scheme (${protocol}:)`,
      desc: "This is a script/data scheme, not a normal web link. Opening it can run client-side JavaScript or reference local system resources directly, putting your browser or machine at high risk.",
    });
  } else {
    checks.push({
      cat: "delivery",
      pass: true,
      weight: 0,
      label: "Standard navigation scheme",
      desc: "The link runs on conventional HTTP/HTTPS routing schemes, which do not auto-execute code on click.",
    });
  }

  const dangerousExt = /\.(exe|scr|bat|cmd|msi|apk|jar|vbs|ps1|dll|lnk|com|pif)(\?|$)/i;
  if (dangerousExt.test(pathname)) {
    checks.push({
      cat: "delivery",
      pass: false,
      weight: 25,
      label: "Direct download of executable/installer",
      desc: "The path points directly to an installer, script, or compiled program file. Legitimate websites do not force direct software downloads from hidden links.",
    });
  } else {
    checks.push({
      cat: "delivery",
      pass: true,
      weight: 0,
      label: "No raw executable payloads",
      desc: "The path does not directly trigger an immediate application or script download.",
    });
  }

  const redirectParams = [
    "redirect",
    "url",
    "next",
    "return",
    "dest",
    "destination",
    "continue",
    "rurl",
    "target",
    "out",
  ];
  let openRedirect = false;
  try {
    for (const key of redirectParams) {
      const val = parsed.searchParams.get(key);
      if (val && /^https?(:\/\/|%3a%2f%2f)/i.test(val)) {
        openRedirect = true;
        break;
      }
    }
  } catch (e) {}

  if (openRedirect) {
    checks.push({
      cat: "delivery",
      pass: false,
      weight: 15,
      label: "Potential open redirect parameter",
      desc: "The URL carries forwarding parameters targeting another domain. Attackers use compromised trusted sites with open redirects to route users to a final malicious landing page.",
    });
  } else {
    checks.push({
      cat: "delivery",
      pass: true,
      weight: 0,
      label: "No open-redirect chaining",
      desc: "No third-party destination routing variables are packed into the query stream.",
    });
  }

  const percentEncodedCount = (raw.match(/%[0-9a-fA-F]{2}/g) || []).length;
  if (percentEncodedCount >= 6) {
    checks.push({
      cat: "delivery",
      pass: false,
      weight: 10,
      label: "Heavy URL character encoding",
      desc: `Found ${percentEncodedCount} percent-encoded tokens. Attackers obscure URLs with extreme encoding to slip bad words past standard firewalls and deceive visual inspectors.`,
    });
  } else {
    checks.push({
      cat: "delivery",
      pass: true,
      weight: 0,
      label: "Standard character representation",
      desc: "The URL does not use excessive escape encoding to mask its actual characters.",
    });
  }

  // Calculate overall score
  const totalWeight = checks.reduce((acc, curr) => acc + curr.weight, 0);
  const score = Math.min(100, totalWeight);

  return {
    error: false,
    hostname,
    url: raw,
    checks,
    score,
  };
}
